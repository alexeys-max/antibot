<?php

/**
 * Deutsches Sprachpaket (Deutsch).
 */

return [
    'html_lang' => 'de-DE',
    'dir'       => 'ltr',

    'title'              => 'Einen Moment…',
    'verifying_text'     => 'Überprüfung läuft…',
    'zone_checking'      => '{site} muss die Sicherheit Ihrer Verbindung überprüfen.',
    'success_text'       => 'Überprüfung erfolgreich',
    'waiting_response'   => 'Warten auf Antwort von {site}…',
    'enable_js_cookies'  => 'Bitte aktivieren Sie JavaScript und Cookies, um fortzufahren',
    'instruction'        => 'Wenn Sie ein Mensch sind, klicken Sie das {color} Kontrollkästchen',
    'session_expired'    => 'Sitzung abgelaufen.',
    'time_out'           => 'Zeit abgelaufen.',
    'refresh'            => 'Aktualisieren',
    'fail_text'          => 'Fehlgeschlagen',
    'having_trouble'     => 'Probleme?',
    'stuck_here'         => 'Hier festgefahren?',
    'send_feedback'      => 'Feedback senden',

    'colors' => [
        'blue'  => 'blaue',
        'green' => 'grüne',
        'red'   => 'rote',
    ],

    'block_title'                => 'Aufmerksamkeit erforderlich!',
    'enable_cookies'             => 'Bitte aktivieren Sie Cookies.',
    'block_headline'             => 'Leider wurden Sie blockiert.',
    'unable_to_access'           => 'Sie können nicht auf',
    'blocked_why_headline'       => 'Warum wurde ich blockiert?',
    'blocked_why_detail'         => 'Diese Website verwendet einen Sicherheitsdienst zum Schutz vor Online-Angriffen. Die gerade ausgeführte Aktion hat die Sicherheitslösung ausgelöst. Mehrere Aktionen können diese Blockierung auslösen, darunter das Senden eines bestimmten Wortes oder einer Phrase, eines SQL-Befehls oder falsch formatierter Daten.',
    'blocked_resolve_headline'   => 'Was kann ich tun, um das zu beheben?',
    'blocked_resolve_detail'     => 'Sie können dem Website-Eigentümer eine E-Mail senden, um ihn darüber zu informieren, dass Sie blockiert wurden. Bitte teilen Sie mit, was Sie getan haben, als diese Seite erschien, und geben Sie die Ray-ID am unteren Rand dieser Seite an.',
    'click_to_reveal'            => 'Zum Anzeigen klicken',
    'your_ip'                    => 'Ihre IP:',

    'ray_id'                     => 'Ray-ID',
];
