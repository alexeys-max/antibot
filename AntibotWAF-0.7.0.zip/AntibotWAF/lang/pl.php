<?php

/**
 * Polski pakiet językowy.
 */

return [
    'html_lang' => 'pl-PL',
    'dir'       => 'ltr',

    'title'              => 'Chwileczkę…',
    'verifying_text'     => 'Weryfikacja…',
    'zone_checking'      => '{site} musi sprawdzić bezpieczeństwo Twojego połączenia.',
    'success_text'       => 'Weryfikacja zakończona pomyślnie',
    'waiting_response'   => 'Oczekiwanie na odpowiedź od {site}…',
    'enable_js_cookies'  => 'Włącz JavaScript i pliki cookies, aby kontynuować',
    'instruction'        => 'Jeśli jesteś człowiekiem, kliknij pole {color}',
    'session_expired'    => 'Sesja wygasła.',
    'time_out'           => 'Czas minął.',
    'refresh'            => 'Odśwież',
    'fail_text'          => 'Błąd',
    'having_trouble'     => 'Problemy?',
    'stuck_here'         => 'Utknąłeś tutaj?',
    'send_feedback'      => 'Wyślij opinię',

    'colors' => [
        'blue'  => 'niebieskie',
        'green' => 'zielone',
        'red'   => 'czerwone',
    ],

    'block_title'                => 'Wymagana uwaga!',
    'enable_cookies'             => 'Włącz pliki cookies.',
    'block_headline'             => 'Przepraszamy, zostałeś zablokowany.',
    'unable_to_access'           => 'Nie masz dostępu do',
    'blocked_why_headline'       => 'Dlaczego zostałem zablokowany?',
    'blocked_why_detail'         => 'Ta strona używa usługi bezpieczeństwa w celu ochrony przed atakami online. Działanie, które właśnie wykonałeś, uruchomiło rozwiązanie zabezpieczające. Kilka działań może spowodować to zablokowanie, w tym wysłanie określonego słowa lub frazy, polecenia SQL lub nieprawidłowo sformułowanych danych.',
    'blocked_resolve_headline'   => 'Co mogę zrobić, aby to rozwiązać?',
    'blocked_resolve_detail'     => 'Możesz wysłać e-mail do właściciela witryny, aby poinformować go, że zostałeś zablokowany. Wskaż, co robiłeś, gdy pojawiła się ta strona, oraz identyfikator Ray ID widoczny na dole tej strony.',
    'click_to_reveal'            => 'Kliknij, aby ujawnić',
    'your_ip'                    => 'Twój IP:',

    'ray_id'                     => 'Ray ID',
];
