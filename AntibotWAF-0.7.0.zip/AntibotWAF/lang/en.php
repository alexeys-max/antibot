<?php

/**
 * English language pack (default).
 */

return [
    'html_lang' => 'en',
    'dir'       => 'ltr',

    // template.inc.php
    'title'              => 'One moment…',
    'verifying_text'     => 'Verifying…',
    'zone_checking'      => '{site} needs to review the security of your connection.',
    'success_text'       => 'Verification successful',
    'waiting_response'   => 'Waiting for {site} to respond…',
    'enable_js_cookies'  => 'Enable JavaScript and cookies to continue',
    'instruction'        => 'If you are human, click the {color} checkbox',
    'session_expired'    => 'Session expired.',
    'time_out'           => 'Time expired.',
    'refresh'            => 'Refresh',
    'fail_text'          => 'Failure',
    'having_trouble'     => 'Having trouble?',
    'stuck_here'         => 'Stuck here?',
    'send_feedback'      => 'Send Feedback',

    // Цвета (для подстановки в instruction)
    'colors' => [
        'blue'  => 'blue',
        'green' => 'green',
        'red'   => 'red',
    ],

    // template_block.inc.php
    'block_title'                => 'Attention required!',
    'enable_cookies'             => 'Please enable cookies.',
    'block_headline'             => 'Sorry, you have been blocked.',
    'unable_to_access'           => 'You cannot access',
    'blocked_why_headline'       => 'Why have I been blocked?',
    'blocked_why_detail'         => 'This website is using a security service to protect from online attacks. The action you just performed triggered the security solution. Several actions could trigger this block, including submitting a certain word or phrase, a SQL command, or malformed data.',
    'blocked_resolve_headline'   => 'What can I do to resolve this?',
    'blocked_resolve_detail'     => 'You can email the site owner to let them know you were blocked. Please include what you were doing when this page came up and the Ray ID at the bottom of this page.',
    'click_to_reveal'            => 'Click to reveal',
    'your_ip'                    => 'Your IP:',

    // footer
    'ray_id'                     => 'Ray ID',
];
