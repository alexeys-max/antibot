<?php

/**
 * Paquet de langue français.
 */

return [
    'html_lang' => 'fr-FR',
    'dir'       => 'ltr',

    'title'              => 'Un instant…',
    'verifying_text'     => 'Vérification en cours…',
    'zone_checking'      => '{site} doit vérifier la sécurité de votre connexion.',
    'success_text'       => 'Vérification réussie',
    'waiting_response'   => 'En attente de la réponse de {site}…',
    'enable_js_cookies'  => 'Veuillez activer JavaScript et les cookies pour continuer',
    'instruction'        => 'Si vous êtes humain, cliquez sur la case {color}',
    'session_expired'    => 'La session a expiré.',
    'time_out'           => 'Temps écoulé.',
    'refresh'            => 'Actualiser',
    'fail_text'          => 'Échec',
    'having_trouble'     => 'Des difficultés ?',
    'stuck_here'         => 'Bloqué ici ?',
    'send_feedback'      => 'Envoyer un commentaire',

    'colors' => [
        'blue'  => 'bleue',
        'green' => 'verte',
        'red'   => 'rouge',
    ],

    'block_title'                => 'Attention requise !',
    'enable_cookies'             => 'Veuillez activer les cookies.',
    'block_headline'             => 'Désolé, vous avez été bloqué.',
    'unable_to_access'           => 'Vous ne pouvez pas accéder à',
    'blocked_why_headline'       => 'Pourquoi ai-je été bloqué ?',
    'blocked_why_detail'         => 'Ce site web utilise un service de sécurité pour se protéger contre les attaques en ligne. L\'action que vous venez d\'effectuer a déclenché la solution de sécurité. Plusieurs actions peuvent déclencher ce blocage, notamment l\'envoi d\'un mot ou d\'une phrase spécifique, d\'une commande SQL ou de données mal formées.',
    'blocked_resolve_headline'   => 'Que puis-je faire pour résoudre ce problème ?',
    'blocked_resolve_detail'     => 'Vous pouvez envoyer un e-mail au propriétaire du site pour l\'informer que vous avez été bloqué. Veuillez indiquer ce que vous faisiez lorsque cette page est apparue ainsi que l\'identifiant Ray ID en bas de cette page.',
    'click_to_reveal'            => 'Cliquez pour révéler',
    'your_ip'                    => 'Votre IP :',

    'ray_id'                     => 'Ray ID',
];
