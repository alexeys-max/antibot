<?php

// БЕЗОПАСНОСТЬ: samesite + httponly + secure + strict_mode против
// session fixation и утечки через XSS/HTTP.
$session_options = [
    'cookie_httponly' => true,
    'cookie_samesite' => 'Lax',
    'use_strict_mode' => true,
    'use_cookies'     => true,
    'use_only_cookies' => true,
];

// Secure-флаг ставим только если запрос пришёл по HTTPS — это безопасно
// и для reverse-proxy сценариев, т.к. проверка делается в includes/HeaderProxy.
if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
    $session_options['cookie_secure'] = true;
} elseif (isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') {
    $session_options['cookie_secure'] = true;
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
    // Заголовок доверяется только если backend уверен в прокси; окончательная
    // проверка выполняется в HeaderProxy, но на момент session_start мы ставим
    // secure уже тут, чтобы кука не ушла по HTTP на стороне браузера.
    $session_options['cookie_secure'] = true;
}

session_start($session_options);

header('Content-type: application/json; charset=utf-8');

include __DIR__ . "/includes/autoload.php";

try {
    $antiBot = new \WAFSystem\WAFSystem();
    $antiBot->isAllowed2();
} catch (Exception $e) {
    error_log("AntiBot system failed: " . $e->getMessage());
    header("HTTP/1.1 500 Internal Server Error");
    exit;
}
