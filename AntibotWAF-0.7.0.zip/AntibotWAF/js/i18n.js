// Antibot i18n.js — переключатель языка без перезагрузки страницы.
//
// Логика:
// 1. На старте страницы язык уже определён сервером (I18N_CURRENT).
// 2. При клике на кнопку переключателя:
//    - Ставим куку antibot_lang=XX (на 365 дней).
//    - Перерисовываем все элементы с data-i18n="key" из I18N_FULL[XX].
//    - Обновляем <html lang> и <title>.
//    - Обновляем active-состояние кнопок переключателя.
//    - Перерисовываем текст инструкции капчи (через I18N_COLORS).
// 3. Перезагрузка страницы НЕ делается — JS-проверка (FPS, fingerprint)
//    продолжается без прерывания.

(function () {
    'use strict';

    if (typeof I18N_FULL === 'undefined') {
        console.warn('I18N_FULL not defined — language switcher disabled');
        return;
    }

    /**
     * Применяет языковой пакет к странице.
     * @param {string} lang Код языка (en/ru/de/fr/pl)
     */
    function applyLanguage(lang) {
        var pack = I18N_FULL[lang];
        if (!pack) {
            console.warn('No language pack for: ' + lang);
            return;
        }

        // 1. Обновляем <html lang> и <dir>.
        if (pack.html_lang) {
            document.documentElement.lang = pack.html_lang;
        }
        if (pack.dir) {
            document.documentElement.dir = pack.dir;
        }

        // 2. Обновляем <title>.
        var titleEl = document.querySelector('title[data-i18n="title"]');
        if (titleEl && pack.title) {
            titleEl.textContent = pack.title;
        }
        var blockTitleEl = document.querySelector('title[data-i18n="block_title"]');
        if (blockTitleEl && pack.block_title) {
            blockTitleEl.textContent = pack.block_title;
        }

        // 3. Обновляем все элементы с data-i18n="key".
        //    Для ключей с плейсхолдером {site} подставляем I18N_SITE_NAME.
        var siteName = (typeof I18N_SITE_NAME !== 'undefined') ? I18N_SITE_NAME : '';
        var elements = document.querySelectorAll('[data-i18n]');
        for (var i = 0; i < elements.length; i++) {
            var el = elements[i];
            var key = el.getAttribute('data-i18n');
            if (!key || !pack.hasOwnProperty(key)) continue;

            var value = pack[key];
            // Подстановка {site}
            if (value.indexOf('{site}') !== -1 && siteName) {
                value = value.replace('{site}', siteName);
            }
            el.textContent = value;
        }

        // 4. Обновляем текст инструкции капчи (если есть элемент pSht7).
        //    Инструкция: "If you are human, click the {color} checkbox"
        //    Цвет подставляется из pack.colors[correctColorKey].
        var instructionEl = document.getElementById('pSht7');
        if (instructionEl && pack.instruction && typeof CORRECT_BOTTOM !== 'undefined') {
            var correctColorKey = (CORRECT_BOTTOM === 1) ? BOTTOM1_COLOR : BOTTOM2_COLOR;
            var colorTranslated = (pack.colors && pack.colors[correctColorKey])
                ? pack.colors[correctColorKey]
                : correctColorKey;
            instructionEl.textContent = pack.instruction.replace('{color}', colorTranslated);
        }

        // 5. Обновляем active-состояние кнопок переключателя.
        var buttons = document.querySelectorAll('.lang-btn');
        for (var j = 0; j < buttons.length; j++) {
            var btn = buttons[j];
            var btnLang = btn.getAttribute('data-lang');
            if (btnLang === lang) {
                btn.classList.add('lang-btn-active');
            } else {
                btn.classList.remove('lang-btn-active');
            }
        }

        // 6. Обновляем глобальную переменную для api.js.
        if (typeof I18N !== 'undefined') {
            // Переносим ключи из pack в I18N (для t() в api.js).
            for (var k in pack) {
                if (pack.hasOwnProperty(k)) {
                    I18N[k] = pack[k];
                }
            }
        }
        if (typeof I18N_COLORS !== 'undefined' && pack.colors) {
            I18N_COLORS = pack.colors;
        }
        I18N_CURRENT = lang;
    }

    /**
     * Ставит куку языка.
     */
    function setLangCookie(lang) {
        var maxAge = 365 * 86400; // 1 год
        var cookie = 'antibot_lang=' + encodeURIComponent(lang) +
            '; path=/; max-age=' + maxAge +
            '; SameSite=Lax';
        if (location.protocol === 'https:') {
            cookie += '; Secure';
        }
        document.cookie = cookie;
    }

    /**
     * Инициализация — навешивает обработчики на кнопки переключателя.
     */
    function init() {
        var buttons = document.querySelectorAll('.lang-btn[data-lang]');
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].addEventListener('click', function () {
                var lang = this.getAttribute('data-lang');
                if (!lang || !I18N_FULL[lang]) return;
                if (lang === I18N_CURRENT) return; // уже активен

                setLangCookie(lang);
                applyLanguage(lang);
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
