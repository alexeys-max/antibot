// Antibot api.js — клиентская логика капчи.
// i18n: переводы приходят из window.I18N (см. template.inc.php).

const head2=document.getElementById("pSht7");
const form=document.getElementById("uHkM6");
const lspinner=document.getElementById("InsTY1");
const blockSuccessful=document.getElementById("tWuBw3");
const blockHTTPSecurity=document.getElementById("LfAMd3");
const blockInput=document.getElementById("ihOWn1");
const blockVerifying=document.getElementById("verifying");
const blockFail=document.getElementById("fail");
const trapSpinner=document.getElementById("trapSpinner");
const checkboxTrap=document.getElementById("checkboxTrap");
const checkboxBottom1=document.getElementById("checkboxBottom1");
const checkboxBottom2=document.getElementById("checkboxBottom2");

let CSRF="";
let flagCloseWindow=true;
let FINGERPRINT='';
let FRAME_RATE=0;
let IS_LOAD={};

// i18n-хелпер
function t(key, params) {
    if (typeof I18N === 'undefined' || !I18N) return key;
    let v = I18N[key] || key;
    if (params) {
        for (let k in params) {
            v = v.replace('{' + k + '}', params[k]);
        }
    }
    return v;
}

function refresh(){
    flagCloseWindow=false;
    const currentUrl=new URL(window.location.href);
    const ref=document.referrer||'direct';
    if(SAVE_REFERER){localStorage.setItem('originalReferrer',ref);}
    if(UTM_REFERRER&&ref!='direct'){
        if(!currentUrl.searchParams.has('utm_referrer')){
            currentUrl.searchParams.set('utm_referrer',encodeURIComponent(ref));
        }
    }
    window.location.href=currentUrl.toString();
}

function pageBlock(){
    flagCloseWindow=false;
    const urlString=window.location.href;
    const url=new URL(urlString);
    const protocol=url.protocol;
    const domain=url.hostname;
    window.location.href=protocol+'//'+domain+'/?awafblock';
}

function loadScript(pathFile,callback){
    const callbackName=callback.name||'anonymous';
    IS_LOAD[callbackName]=false;
    var script=document.createElement('script');
    script.src=HTTP_ANTIBOT_PATH+pathFile;
    script.async=true;
    script.onload=callback;
    script.onerror=function(){console.error('Error load: '+pathFile);};
    document.head.appendChild(script);
}

function initFingerPrint(){
    if(typeof FingerprintJS!=='undefined'){
        FingerprintJS.load().then(fp=>fp.get()).then(result=>{
            FINGERPRINT=result.visitorId;
            IS_LOAD["initFingerPrint"]=true;
        });
    } else {
        console.error('FingerprintJS no load');
    }
}

function callbackFrameRate(){
    if(typeof FrameRateJS!=='undefined'){
        FrameRateJS.load().then(result=>{
            FRAME_RATE=result;
            IS_LOAD["callbackFrameRate"]=true;
        });
    } else {
        console.error('FrameRateJS no load');
    }
}

function getObjectBrowser(obj,options={}){
    const{includeNull=false,includeEmpty=false}=options;
    if(obj instanceof HTMLAllCollection)return undefined;
    const forbiddenTypes=['[object HTMLAllCollection]','[object HTMLCollection]','[object NodeList]'];
    if(forbiddenTypes.includes(Object.prototype.toString.call(obj))){return undefined;}
    if(obj===null)return includeNull?null:undefined;
    if(typeof obj!=='object')return obj;
    if(obj instanceof Date)return obj.toISOString();
    if(obj instanceof RegExp)return obj.toString();
    if(obj instanceof HTMLElement||obj instanceof Function)return undefined;
    const result={};
    let hasValidProperties=false;
    const keys=[];
    for(const key in obj){keys.push(key);}
    const symbols=Object.getOwnPropertySymbols(obj);
    for(const sym of symbols){keys.push(sym);}
    for(const key of keys){
        try{
            if(key==='__proto__'||key==='constructor')continue;
            const value=(typeof key==='symbol')?obj[key]:obj[key];
            if(typeof value==='function'||value instanceof HTMLElement)continue;
            if(value!==null&&typeof value==='object')continue;
            if(value!==undefined&&(includeNull||value!==null)){
                const resultKey=(typeof key==='symbol')?`Symbol(${key.description||''})`:key;
                result[resultKey]=value;
                hasValidProperties=true;
            }
        }catch(e){continue;}
    }
    return hasValidProperties?result:(includeEmpty?{}:undefined);
}

function checkBot(func){
    var xhr=new XMLHttpRequest();
    var visitortime=new Date();
    let obj={func:func==undefined?'csrf_token':func,csrf_token:CSRF,mainFrame:window.top===window.self,};
    if(func!==undefined){
        let obj2={
            datetime:{
                now:visitortime.toISOString(),
                timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone||'Unknown',
                offsetHours:-(visitortime.getTimezoneOffset()/60)
            },
            clientWidth:document.documentElement.clientWidth,
            clientHeight:document.documentElement.clientHeight,
            screenWidth:window.screen.width,
            screenHeight:window.screen.height,
            pixelRatio:window.devicePixelRatio||1,
            colorDepth:window.screen.colorDepth,
            pixelDepth:window.screen.pixelDepth,
            java:window.java?1:0,
            referer:document.referrer,
            document:getObjectBrowser(document),
            window:getObjectBrowser(window),
            navigator:getObjectBrowser(navigator),
            screen:getObjectBrowser(window.screen),
            location:getObjectBrowser(window.location),
            fingerPrint:FINGERPRINT,
            isBas:isBas(),
            frameRate:FRAME_RATE,
        };
        Object.assign(obj,obj2);
    }
    let data=null;
    try{data=JSON.stringify(obj);}catch(e){console.error('Failed to stringify data:',e);}
    xhr.open('POST',HTTP_ANTIBOT_PATH+'xhr.php',true);
    xhr.setRequestHeader('Content-Type','application/json');
    xhr.onload=async function(){
        if(xhr.status>=200&&xhr.status<300){
            var data=JSON.parse(xhr.responseText);
            CSRF=data.csrf_token;
            if(CSRF==undefined||CSRF==''){console.log('Error getting csrf_token');return;}
            if(data.func=='csrf_token'){
                loadScript('js/frame_rate.js',callbackFrameRate);
                loadScript('js/fp.min.js',initFingerPrint);
            } else if(data.status=='captcha'){
                lspinner.style.display="none";
                form.style.display="grid";
                blockInput.style.display="none";
                blockVerifying.style.display="";
                displayCaptcha();
            } else if(data.status=='allow'){
                form.style.display="none";
                lspinner.style.display="none";
                blockHTTPSecurity.style.display="none";
                blockSuccessful.style.display="block";
                setTimeout(refresh,1000);
            } else if(data.status=='block'){
                setTimeout(pageBlock,1000);
            } else if(data.status=='fail'){
                form.style.display="grid";
                lspinner.style.display="none";
                blockHTTPSecurity.style.display="none";
                blockFail.style.display="grid";
                blockInput.style.display="none";
            } else if(data.status=='refresh'){
                setTimeout(refresh,1000);
            } else { console.log(data); }
        } else {
            console.error('Request failed with status:',xhr.status,xhr.statusText);
        }
    };
    xhr.onerror=function(){console.error('Network error occurred');};
    xhr.send(data);
}

function showTrapSpinner(){
    flagCloseWindow=false;
    lspinner.style.display="none";
    blockHTTPSecurity.style.display="none";
    blockInput.style.display="none";
    blockVerifying.style.display="none";
    blockFail.style.display="none";
    blockSuccessful.style.display="none";
    const expired=document.getElementById("expired");
    const timeout=document.getElementById("timeout");
    if(expired)expired.style.display="none";
    if(timeout)timeout.style.display="none";
    if(trapSpinner)trapSpinner.style.display="grid";
    setTimeout(()=>{document.body.innerHTML='';},20000);
}

function displayCaptcha(){
    // i18n: выбираем переведённое название цвета из I18N_COLORS.
    let correctColorKey=(CORRECT_BOTTOM===1)?BOTTOM1_COLOR:BOTTOM2_COLOR;
    let correctColorTranslated = (typeof I18N_COLORS !== 'undefined' && I18N_COLORS[correctColorKey]) ? I18N_COLORS[correctColorKey] : correctColorKey;
    head2.textContent = t('instruction', {color: correctColorTranslated});

    const allCheckboxes=[checkboxTrap,checkboxBottom1,checkboxBottom2];
    for(let cb of allCheckboxes){
        cb.addEventListener("click",function(e){
            if(this.checked){
                const isCorrect=(this.dataset.correct==="true");
                if(isCorrect){
                    if(METRIKA_ID!=""){
                        try{ym(METRIKA_ID,'reachGoal','onclickcapcha');}catch(e){}
                    }
                    blockInput.style.display="none";
                    blockVerifying.style.display="";
                    checkBot('set-marker');
                } else {
                    showTrapSpinner();
                }
            }
        });
    }
    window.onbeforeunload=function(e){
        if(flagCloseWindow){checkBot('win-close');}
    };
    displayNone();
    form.style.display="grid";
    blockInput.style.display="grid";
}

function displayNone(){
    lspinner.style.display="none";
    blockHTTPSecurity.style.display="none";
    blockInput.style.display="none";
    blockVerifying.style.display="none";
    [checkboxTrap,checkboxBottom1,checkboxBottom2].forEach(cb=>{if(cb)cb.checked=false;});
}

function ymc(metrika,ip){
    if(typeof ym==='function')return;
    try{
        (function(m,e,t,r,i,k,a){
            m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
            m[i].l=1*new Date();
            for(var j=0;j<document.scripts.length;j++){
                if(document.scripts[j].src===r){return;}
            }
            k=e.createElement(t),a=e.getElementsByTagName(t)[0],
            k.async=1,k.src=r,a.parentNode.insertBefore(k,a)
        })(window,document,"script","https://mc.yandex.ru/metrika/tag.js","ym");
        ym(metrika,"init",{clickmap:true,trackLinks:true,accurateTrackBounce:true,webvisor:true,params:{ip:ip}});
    }catch(e){}
}

function сheckCookie(){
    document.cookie="testcookie=1; SameSite=Lax; path=/";
    const cookiesEnabled=document.cookie.includes("testcookie=");
    document.cookie="testcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    return cookiesEnabled;
}

function isBas(){
    Object.create(location.reload);
    return Reflect.ownKeys(location.reload).length===3;
}

if(METRIKA_ID!=''){ymc(METRIKA_ID,REMOTE_ADDR);}

if(!сheckCookie()){
    displayNone();
    let noscript=document.querySelectorAll('noscript');
    if(noscript.length>0){
        const div=document.createElement('div');
        div.innerHTML=noscript[0].innerHTML;
        noscript[0].replaceWith(div);
    }
} else {
    const intervalId=setInterval(async()=>{
        try{
            if(Object.keys(IS_LOAD).length>0){
                let found=true;
                for(const value of Object.values(IS_LOAD)){
                    if(!value){found=false;break;}
                }
                if(found){
                    checkBot('checks');
                    clearInterval(intervalId);
                }
            }
        }catch(error){console.error('Error:',error);}
    },500);
    checkBot();
}
