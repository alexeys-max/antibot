<?php

# Файл подключается из index.php целевого сайта через:
#   require_once $_SERVER['DOCUMENT_ROOT'].'/antibot/index.php';
# либо через .htaccess (тогда $isInclude может быть уже выставлен).

$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$request_uri = is_string($request_uri) ? $request_uri : '';

if (basename($request_uri) !== 'xhr.php' && !isset($isInclude)) {
    // Флаг защищает от повторного подключения при .htaccess-режиме.
    $isInclude = true;

    include __DIR__ . "/includes/autoload.php";

    // Инициализация и запуск системы.
    // WAF запускается на КАЖДОМ запросе (безусловная проверка).
    // Раннее короткое замыкание по валидному маркеру делается внутри WAFSystem::isAllowed().
    try {
        $antiBot = new \WAFSystem\WAFSystem();
        if ($antiBot->enabled) {
            $antiBot->IFrameChecker->HeaderBlock(); // заголовки X-Frame-Options / CSP

            if (isset($_GET['awafblock'])) {
                // Явный запрос блок-страницы (после неудачной капчи на клиенте).
                $antiBot->Template->showBlockPage();
            }

            $antiBot->run();
        }
    } catch (Exception $e) {
        error_log("AntiBot system failed: " . $e->getMessage());
        header("HTTP/1.1 500 Internal Server Error");
        exit;
    }
}
