<?php

/**
 * Smoke-тесты — проверка базовой функциональности antibot без запуска веб-сервера.
 *
 * Запуск: php tests/smoke/run.php
 *
 * Тесты НЕ требуют PHPUnit — это простые assert-функции.
 * Возвращают 0 если все тесты прошли, 1 если хотя бы один упал.
 *
 * ВАЖНО: тесты модифицируют config.ini через Config::set(). Чтобы не
 * оставлять побочных эффектов, перед запуском делается резервная копия
 * config.ini → config.ini.smoke_bak, и восстанавливается после (даже
 * при ошибке).
 */

namespace WAFSystem;

// Эмулируем окружение веб-запроса для CLI.
// __DIR__ = AntibotWAF/tests/smoke
// dirname(__DIR__, 3) = родитель AntibotWAF = DOCUMENT_ROOT сайта
$_SERVER['DOCUMENT_ROOT'] = dirname(__DIR__, 3);
$_SERVER['HTTP_HOST'] = 'example.com';
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (X11; Linux x86_64) SmokeTest/1.0';
$_SERVER['HTTP_REFERER'] = '';
$_SERVER['SERVER_PROTOCOL'] = 'HTTP/1.1';
$_SERVER['REQUEST_SCHEME'] = 'http';
$_SERVER['PHP_SELF'] = __FILE__;
$_SERVER['HTTP_ACCEPT_LANGUAGE'] = 'en-US,en;q=0.9,ru;q=0.8';

// Подавляем warnings от setcookie() — в CLI заголовки уже отправлены
// выводом, и setcookie() шумит. На логику не влияет.
error_reporting(E_ALL & ~E_WARNING);

// Резервная копия config.ini — восстанавливается в shutdown-handler.
// __DIR__ = AntibotWAF/tests/smoke, поднимаемся на 2 уровня = AntibotWAF
$antibotBasePath = dirname(__DIR__, 2);
$configIniPath = $antibotBasePath . '/config.ini';
$backupPath = $configIniPath . '.smoke_bak';
if (is_file($configIniPath)) {
    copy($configIniPath, $backupPath);
}
register_shutdown_function(function () use ($configIniPath, $backupPath) {
    if (is_file($backupPath)) {
        // Восстанавливаем оригинальный config.ini.
        @copy($backupPath, $configIniPath);
        @unlink($backupPath);
    }
});

require_once $antibotBasePath . '/includes/autoload.php';

$total = 0;
$passed = 0;
$failed = 0;
$failures = [];

function assert_true(bool $cond, string $name, string $msg = ''): void {
    global $total, $passed, $failed, $failures;
    $total++;
    if ($cond) {
        $passed++;
        echo "  ✓ $name\n";
    } else {
        $failed++;
        $failures[] = $name . ($msg ? " — $msg" : '');
        echo "  ✗ $name" . ($msg ? " — $msg" : '') . "\n";
    }
}

echo "\n=== Smoke tests ===\n\n";

// ===== 1. Config =====
echo "[1] Config loading\n";
try {
    $config = Config::getInstance();
    assert_true($config instanceof Config, 'Config instance created');
    assert_true($config->get('main', 'enabled') === true, 'main.enabled is true');
    assert_true($config->get('i18n', 'default_lang') === 'en', 'i18n.default_lang is en');
    assert_true($config->get('header_proxy', 'enabled') === false, 'header_proxy.enabled is false by default');
} catch (\Throwable $e) {
    assert_true(false, 'Config load', $e->getMessage());
}

// ===== 2. Profile =====
echo "\n[2] Profile (HMAC marker secret)\n";
try {
    $profile = Profile::getInstance($config);
    assert_true(strlen($profile->RayID) === 16, 'RayID is 16 hex chars');
    assert_true(ctype_xdigit($profile->RayID), 'RayID is hex');
    assert_true(strlen($profile->RayIDSecret) === 32, 'RayIDSecret is 32 hex chars');
    assert_true(ctype_xdigit($profile->RayIDSecret), 'RayIDSecret is hex');

    // Проверка, что секрет сгенерирован как 64 hex (256 бит).
    $secret = $profile->getMarkerSecret();
    assert_true(strlen($secret) === 64, 'Marker secret is 64 hex chars (256 bit)');
    assert_true(ctype_xdigit($secret), 'Marker secret is hex');

    // Проверка verifyMarkerValue.
    $expires = time() + 3600;
    $value = $profile->computeMarkerValue($expires);
    assert_true($profile->verifyMarkerValue($value), 'Marker value verifies (valid)');
    assert_true(!$profile->verifyMarkerValue('garbage'), 'Marker value rejects garbage');
    assert_true(!$profile->verifyMarkerValue('aa.bb.cc'), 'Marker value rejects malformed');
    assert_true(!$profile->verifyMarkerValue($expires . '.tampered.signature'), 'Marker value rejects tampered');
} catch (\Throwable $e) {
    assert_true(false, 'Profile', $e->getMessage());
}

// ===== 3. Marker =====
echo "\n[3] Marker cookie\n";
try {
    $logger = new Logger($config, $profile);
    $marker = new Marker($config, $profile, $logger);
    assert_true(!$marker->isValid(), 'Marker invalid before set()');
    $marker->set();
    assert_true($marker->isValid(), 'Marker valid after set()');

    // Подделка значения не должна проходить.
    $_COOKIE[$profile->RayIDSecret] = 'fake';
    assert_true(!$marker->isValid(), 'Marker rejects fake value');
    unset($_COOKIE[$profile->RayIDSecret]);
} catch (\Throwable $e) {
    assert_true(false, 'Marker', $e->getMessage());
}

// ===== 4. HeaderProxy (trusted proxies) =====
echo "\n[4] HeaderProxy (trusted proxies)\n";
try {
    // По умолчанию trusted_proxies пустой — заголовок не доверяется.
    $_SERVER['REMOTE_ADDR'] = '8.8.8.8';
    $_SERVER['HTTP_X_FORWARDED_FOR'] = '1.2.3.4';
    $hp = new HeaderProxy($config);
    assert_true($hp->getIPAddr() === '8.8.8.8', 'XFF ignored when no trusted proxies');

    // С trusted_proxy = REMOTE_ADDR — заголовок доверяется.
    $config->set('header_proxy', 'enabled', true);
    $config->set('header_proxy', 'trusted_proxies', '8.8.8.8');
    $hp2 = new HeaderProxy($config);
    assert_true($hp2->getIPAddr() === '1.2.3.4', 'XFF trusted when REMOTE_ADDR in trusted_proxies');

    // Если REMOTE_ADDR не в trusted_proxies — заголовок не доверяется.
    $_SERVER['REMOTE_ADDR'] = '9.9.9.9';
    $hp3 = new HeaderProxy($config);
    assert_true($hp3->getIPAddr() === '9.9.9.9', 'XFF ignored when REMOTE_ADDR not trusted');

    // Cleanup
    $config->set('header_proxy', 'enabled', false);
    $config->set('header_proxy', 'trusted_proxies', '');
    $_SERVER['REMOTE_ADDR'] = '127.0.0.1';
    unset($_SERVER['HTTP_X_FORWARDED_FOR']);
} catch (\Throwable $e) {
    assert_true(false, 'HeaderProxy', $e->getMessage());
}

// ===== 5. Network =====
echo "\n[5] Network utility\n";
try {
    assert_true(\Utility\Network::isInRange('192.168.1.5', '192.168.1.0/24'), 'IP in CIDR');
    assert_true(!\Utility\Network::isInRange('192.168.2.5', '192.168.1.0/24'), 'IP not in CIDR');
    assert_true(\Utility\Network::isInRange('192.168.1.5', '192.168.1.1-192.168.1.10'), 'IP in range');
    assert_true(\Utility\Network::validateASN('AS8637'), 'AS8637 valid');
    assert_true(\Utility\Network::validateASN('8637'), '8637 valid (no AS prefix)');
    assert_true(!\Utility\Network::validateASN('invalid'), 'ASN rejects invalid');
} catch (\Throwable $e) {
    assert_true(false, 'Network', $e->getMessage());
}

// ===== 6. I18n =====
echo "\n[6] I18n (multilingual support)\n";
try {
    $i18n = I18n::getInstance($config);
    assert_true(in_array('en', $i18n->getAvailableLangs()), 'en in available langs');
    assert_true(in_array('ru', $i18n->getAvailableLangs()), 'ru in available langs');
    assert_true(in_array('de', $i18n->getAvailableLangs()), 'de in available langs');
    assert_true(in_array('fr', $i18n->getAvailableLangs()), 'fr in available langs');
    assert_true(in_array('pl', $i18n->getAvailableLangs()), 'pl in available langs');

    // Accept-Language: en-US,en;q=0.9,ru;q=0.8 → должно выбрать en.
    assert_true($i18n->getCurrentLang() === 'en', 'Auto-detect en from Accept-Language');

    // ?lang=de — должно переключить на de.
    $_GET['lang'] = 'de';
    $config2 = Config::getInstance();
    // Сбрасываем синглтон тестовым путём — через reflection.
    $ref = new \ReflectionClass(I18n::class);
    $prop = $ref->getProperty('_instances');
    $prop->setAccessible(true);
    $prop->setValue(null, null);
    $i18n2 = I18n::getInstance($config2);
    assert_true($i18n2->getCurrentLang() === 'de', 'Switch to de via ?lang=de');

    // Проверка перевода.
    $pack = $i18n2->getPack();
    assert_true($pack['html_lang'] === 'de-DE', 'de pack has html_lang=de-DE');
    assert_true(strpos($pack['block_headline'], 'blockiert') !== false, 'de block_headline translated');

    // ?lang=fr
    $_GET['lang'] = 'fr';
    $prop->setValue(null, null);
    $i18n3 = I18n::getInstance($config2);
    assert_true($i18n3->getCurrentLang() === 'fr', 'Switch to fr via ?lang=fr');
    $packFr = $i18n3->getPack();
    assert_true(strpos($packFr['block_headline'], 'bloqué') !== false, 'fr block_headline translated');

    // ?lang=pl
    $_GET['lang'] = 'pl';
    $prop->setValue(null, null);
    $i18n4 = I18n::getInstance($config2);
    assert_true($i18n4->getCurrentLang() === 'pl', 'Switch to pl via ?lang=pl');
    $packPl = $i18n4->getPack();
    assert_true(strpos($packPl['block_headline'], 'zablokowany') !== false, 'pl block_headline translated');

    // ?lang=ru
    $_GET['lang'] = 'ru';
    $prop->setValue(null, null);
    $i18n5 = I18n::getInstance($config2);
    assert_true($i18n5->getCurrentLang() === 'ru', 'Switch to ru via ?lang=ru');
    $packRu = $i18n5->getPack();
    assert_true(strpos($packRu['block_headline'], 'заблокирован') !== false, 'ru block_headline translated');

    // Несуществующий язык — должен упасть на default (en).
    // ВАЖНО: очищаем cookie, чтобы предыдущий выбор (ru) не повлиял.
    unset($_GET['lang']);
    unset($_COOKIE['antibot_lang']);
    $prop->setValue(null, null);
    $i18n6 = I18n::getInstance($config2);
    assert_true($i18n6->getCurrentLang() === 'en', 'Unknown lang falls back to default');
} catch (\Throwable $e) {
    assert_true(false, 'I18n', $e->getMessage() . "\n" . $e->getTraceAsString());
}

// ===== 7. ListBase (path traversal protection) =====
echo "\n[7] Path traversal protection\n";
try {
    // Попытка использовать путь с ../ должна быть нейтрализована.
    $config->set('ip_checker', 'blacklist_ip', 'lists/blacklist_ip');
    $bl = new BlackListIP($config, $logger);
    $absPath = (new \ReflectionClass($bl))->getProperty('absolutePath');
    $absPath->setAccessible(true);
    $path = $absPath->getValue($bl);
    assert_true(strpos($path, '..') === false, 'No path traversal in default list path');
    assert_true(strpos($path, $antibotBasePath) === 0, 'List path within BasePath');

    // APCu-кеш getEntries должен вернуть массив.
    $entriesMethod = (new \ReflectionClass($bl))->getMethod('getEntries');
    $entriesMethod->setAccessible(true);
    $entries = $entriesMethod->invoke($bl);
    assert_true(is_array($entries), 'getEntries returns array');
} catch (\Throwable $e) {
    assert_true(false, 'ListBase', $e->getMessage());
}

// ===== 8. Logger (sanitize CRLF) =====
echo "\n[8] Logger CRLF sanitization\n";
try {
    $ref = new \ReflectionClass($logger);
    $method = $ref->getMethod('sanitizeForLog');
    $method->setAccessible(true);

    $input = "line1\r\nline2\ttab";
    $cleaned = $method->invoke($logger, $input);
    assert_true(strpos($cleaned, "\r") === false, 'CR stripped');
    assert_true(strpos($cleaned, "\n") === false, 'LF stripped');
    assert_true(strpos($cleaned, "\t") === false, 'TAB stripped');
} catch (\Throwable $e) {
    assert_true(false, 'Logger', $e->getMessage());
}

// ===== 9. SysUpdate (branch validation) =====
echo "\n[9] SysUpdate branch validation\n";
try {
    $sys = new SysUpdate($config, $logger);
    $ref = new \ReflectionClass($sys);
    $prop = $ref->getProperty('branch');
    $prop->setAccessible(true);

    // Валидные имена
    $validNames = ['master', 'dev', 'feature-123', 'release.v2'];
    foreach ($validNames as $name) {
        $ok = preg_match('/^[a-zA-Z0-9._-]+$/', $name) === 1;
        assert_true($ok, "Branch name '$name' passes regex");
    }

    // Невалидные — с ../ или специальные символы
    $invalidNames = ['../etc', 'master;rm -rf', 'main||cat /etc/passwd'];
    foreach ($invalidNames as $name) {
        $ok = preg_match('/^[a-zA-Z0-9._-]+$/', $name) === 1;
        assert_true(!$ok, "Branch name '$name' rejected by regex");
    }
} catch (\Throwable $e) {
    assert_true(false, 'SysUpdate', $e->getMessage());
}

// ===== 10. Curl (URL scheme restriction) =====
echo "\n[10] Curl URL scheme restriction\n";
try {
    $curl = new \Utility\Curl(5);

    // file:// должен быть отклонён.
    $rejected = false;
    try {
        $curl->fetch('file:///etc/passwd');
    } catch (\InvalidArgumentException $e) {
        $rejected = true;
    } catch (\Throwable $e) {
        // Другие ошибки тоже ок, главное — не вернул контент
        $rejected = true;
    }
    assert_true($rejected, 'file:// scheme rejected');

    // gopher:// тоже
    $rejected = false;
    try {
        $curl->fetch('gopher://localhost/x');
    } catch (\InvalidArgumentException $e) {
        $rejected = true;
    } catch (\Throwable $e) {
        $rejected = true;
    }
    assert_true($rejected, 'gopher:// scheme rejected');
} catch (\Throwable $e) {
    assert_true(false, 'Curl', $e->getMessage());
}

// ===== 11. WhiteListIP (no HTTP_HOST in eventInitListFile) =====
echo "\n[11] WhiteListIP uses gethostname, not HTTP_HOST\n";
try {
    $wl = new WhiteListIP($config, $logger);
    $ref = new \ReflectionClass($wl);
    $method = $ref->getMethod('eventInitListFile');
    $src = file_get_contents(__DIR__ . '/../../includes/Checks/WhiteListIP.class.php');
    assert_true(strpos($src, '$_SERVER["HTTP_HOST"]') === false, 'WhiteListIP does not use HTTP_HOST');
    assert_true(strpos($src, 'gethostname()') !== false, 'WhiteListIP uses gethostname()');
} catch (\Throwable $e) {
    assert_true(false, 'WhiteListIP', $e->getMessage());
}

// ===== 12. index.php (no Referer gate) =====
echo "\n[12] index.php has no Referer-based gate\n";
try {
    $src = file_get_contents(__DIR__ . '/../../index.php');
    assert_true(strpos($src, 'HTTP_REFERER') === false, 'index.php does not check HTTP_REFERER');
} catch (\Throwable $e) {
    assert_true(false, 'index.php', $e->getMessage());
}

// ===== Итог =====
echo "\n=== Summary ===\n";
echo "Total: $total\n";
echo "Passed: $passed\n";
echo "Failed: $failed\n";

if (!empty($failures)) {
    echo "\nFailures:\n";
    foreach ($failures as $f) {
        echo "  - $f\n";
    }
}

exit($failed === 0 ? 0 : 1);
