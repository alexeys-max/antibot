<?php

/**
 * CRON: обновление списков TOR exit-нод.
 *
 * Запуск: php /path/to/antibot/cron/refresh_tor.php
 * Рекомендуемая частота: раз в 24 часа (dan.me.uk rate-limit 1 запрос / 30 мин).
 *
 * ВАЖНО: ранее обновление Tor-списка запускалось из запроса, что при cache miss
 * блокировало FPM-воркер на 2+ секунды. Теперь — только в cron.
 */

namespace WAFSystem;

$_SERVER['DOCUMENT_ROOT'] ??= dirname(__DIR__, 2);
$_SERVER['HTTP_HOST'] ??= 'cli';
$_SERVER['REQUEST_URI'] ??= '';
$_SERVER['REQUEST_METHOD'] ??= 'GET';
$_SERVER['REMOTE_ADDR'] ??= '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] ??= 'cli';
$_SERVER['HTTP_REFERER'] ??= '';
$_SERVER['SERVER_PROTOCOL'] ??= 'HTTP/1.1';
$_SERVER['REQUEST_SCHEME'] ??= 'http';
$_SERVER['PHP_SELF'] ??= __FILE__;

require_once __DIR__ . '/../includes/autoload.php';

try {
    $config = Config::getInstance();
    $profile = Profile::getInstance($config);
    $logger = new Logger($config, $profile);

    if (!$config->get('tor_checker', 'enabled', false)) {
        fwrite(STDERR, "Tor checker disabled, nothing to do.\n");
        exit(0);
    }

    $tor = new TorChecker($config, $logger);

    // Принудительно обновляем список.
    $reflection = new \ReflectionClass($tor);
    $prop = $reflection->getProperty('absolutePath');
    $prop->setAccessible(true);
    $absPath = $prop->getValue($tor);

    $method = $reflection->getMethod('createDefaultFileContent');
    $method->setAccessible(true);
    $content = $method->invoke($tor);

    if (!empty($content)) {
        // touch filemtime forward so isTor doesn't immediately re-trigger download
        file_put_contents($absPath, $content);
        $now = time();
        touch($absPath, $now, $now);
        $logger->log("Tor list refreshed via cron, " . strlen($content) . " bytes");
        fwrite(STDOUT, "Tor list refreshed.\n");
    } else {
        fwrite(STDERR, "Tor list download returned empty.\n");
        exit(2);
    }

    exit(0);
} catch (\Throwable $e) {
    fwrite(STDERR, "ERROR: " . $e->getMessage() . "\n");
    fwrite(STDERR, $e->getTraceAsString() . "\n");
    exit(1);
}
