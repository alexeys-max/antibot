<?php

/**
 * CRON: ротация лог-файлов antibot.
 *
 * Запуск: php /path/to/antibot/cron/rotate_logs.php
 * Рекомендуемая частота: раз в час.
 *
 * ВАЖНО: этот скрипт запускает ротацию ВНЕ запроса, что убирает
 *瓶颈 из Api::__construct (раньше ротация запускалась при запросе
 * csrf_token, что могло приводить к задержкам под нагрузкой).
 */

namespace WAFSystem;

$_SERVER['DOCUMENT_ROOT'] ??= dirname(__DIR__, 2);
$_SERVER['HTTP_HOST'] ??= 'cli';
$_SERVER['REQUEST_URI'] ??= '';
$_SERVER['REQUEST_METHOD'] ??= 'GET';
$_SERVER['REMOTE_ADDR'] ??= '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] ??= 'cli';
$_SERVER['HTTP_REFERER'] ??= '';
$_SERVER['SERVER_PROTOCOL'] ??= 'HTTP/1.1';
$_SERVER['REQUEST_SCHEME'] ??= 'http';
$_SERVER['PHP_SELF'] ??= __FILE__;

require_once __DIR__ . '/../includes/autoload.php';

try {
    $config = Config::getInstance();
    $profile = Profile::getInstance($config);
    $logger = new Logger($config, $profile);

    $logger->rotateIfNeeded();
    fwrite(STDERR, "Log rotation check completed at " . date('c') . "\n");
    exit(0);
} catch (\Throwable $e) {
    fwrite(STDERR, "ERROR: " . $e->getMessage() . "\n");
    fwrite(STDERR, $e->getTraceAsString() . "\n");
    exit(1);
}
