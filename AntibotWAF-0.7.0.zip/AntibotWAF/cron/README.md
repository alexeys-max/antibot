# Cron jobs

Эти скрипты переносят ресурсоёмкие операции из HTTP-запроса в фон.

## rotate_logs.php — ротация логов
```
0 * * * *  /usr/bin/php /var/www/site/antibot/cron/rotate_logs.php >> /var/www/site/antibot/logs/cron.log 2>&1
```
Запускается каждый час. Если `antibot.log` превышает `max_size` (MB),
поворачивает архивы и сжимает старый в `.gz`.

## refresh_tor.php — обновление списка Tor exit-нод
```
0 3 * * *  /usr/bin/php /var/www/site/antibot/cron/refresh_tor.php >> /var/www/site/antibot/logs/cron.log 2>&1
```
Раз в сутки. Скачивает актуальный список с dan.me.uk.
Внимание: dan.me.uk лимитирует до 1 запроса в 30 минут — не ставьте чаще.

## refresh_asn.php — обновление базы ASN
```
0 4 * * 1  /usr/bin/php /var/www/site/antibot/cron/refresh_asn.php >> /var/www/site/antibot/logs/cron.log 2>&1
```
Раз в неделю (данные ipverse обновляются редко).
Для каждого ASN из `lists/blacklist_asn`/`whitelist_asn`/`captcha_asn`
скачивает aggregated.json и обновляет SQLite-кеш.

## update.php — обновление antibot из GitHub
```
# запускать вручную, не по cron
php /var/www/site/antibot/cron/update.php [--force]
```
Без `--force` обновление выполняется только если в `config.ini` выставлено
`[sysupdate] enabled = On`. С `--force` — проверяет и обновляет всегда.

## Заметки по безопасности
- Все скрипты эмулируют минимальный набор `$_SERVER` переменных, чтобы
  конструкторы классов не падали в CLI-режиме.
- IP `127.0.0.1` по умолчанию находится в whitelist (если это не так —
  добавьте его вручную в `lists/whitelist_ip`).
- Запуск от пользователя веб-сервера (www-data/nginx), чтобы права на
  запись в `logs/` и `cache/` были корректными.
