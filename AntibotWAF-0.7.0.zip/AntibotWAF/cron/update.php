<?php

/**
 * CLI: запуск обновления системы из GitHub-репозитория.
 *
 * Запуск: php /path/to/antibot/cron/update.php [--force]
 *
 * БЕЗОПАСНОСТЬ: обновление запускается только вручную администратором,
 * не из запроса пользователя. Файлы валидируются на path traversal при
 * распаковке ZIP (см. SysUpdate::Update()).
 */

namespace WAFSystem;

$_SERVER['DOCUMENT_ROOT'] ??= dirname(__DIR__, 2);
$_SERVER['HTTP_HOST'] ??= 'cli';
$_SERVER['REQUEST_URI'] ??= '';
$_SERVER['REQUEST_METHOD'] ??= 'GET';
$_SERVER['REMOTE_ADDR'] ??= '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] ??= 'cli';
$_SERVER['HTTP_REFERER'] ??= '';
$_SERVER['SERVER_PROTOCOL'] ??= 'HTTP/1.1';
$_SERVER['REQUEST_SCHEME'] ??= 'http';
$_SERVER['PHP_SELF'] ??= __FILE__;

require_once __DIR__ . '/../includes/autoload.php';

$force = in_array('--force', $argv ?? [], true);

try {
    $config = Config::getInstance();
    $profile = Profile::getInstance($config);
    $logger = new Logger($config, $profile);

    $updater = new SysUpdate($config, $logger);
    $updater->run($force);

    fwrite(STDOUT, "Update check completed.\n");
    exit(0);
} catch (\Throwable $e) {
    fwrite(STDERR, "ERROR: " . $e->getMessage() . "\n");
    fwrite(STDERR, $e->getTraceAsString() . "\n");
    exit(1);
}
