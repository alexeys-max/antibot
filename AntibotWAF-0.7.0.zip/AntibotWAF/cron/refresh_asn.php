<?php

/**
 * CRON: обновление SQLite-базы ASN (для блокировки/капчи по автономным системам).
 *
 * Запуск: php /path/to/antibot/cron/refresh_asn.php
 * Рекомендуемая частота: раз в 7-30 дней (данные ipverse обновляются редко).
 *
 * ВАЖНО: ранее обновление базы запускалось из запроса и при cache miss
 * блокировало FPM-воркеры на 2-10 секунд под эксклюзивным lock (HTTP-фетчи
 * по 2 сек на каждый ASN). Теперь — только в cron.
 */

namespace WAFSystem;

$_SERVER['DOCUMENT_ROOT'] ??= dirname(__DIR__, 2);
$_SERVER['HTTP_HOST'] ??= 'cli';
$_SERVER['REQUEST_URI'] ??= '';
$_SERVER['REQUEST_METHOD'] ??= 'GET';
$_SERVER['REMOTE_ADDR'] ??= '127.0.0.1';
$_SERVER['HTTP_USER_AGENT'] ??= 'cli';
$_SERVER['HTTP_REFERER'] ??= '';
$_SERVER['SERVER_PROTOCOL'] ??= 'HTTP/1.1';
$_SERVER['REQUEST_SCHEME'] ??= 'http';
$_SERVER['PHP_SELF'] ??= __FILE__;

require_once __DIR__ . '/../includes/autoload.php';

try {
    $config = Config::getInstance();
    $profile = Profile::getInstance($config);
    $logger = new Logger($config, $profile);

    if (!$config->get('asn_checker', 'enabled', false)) {
        fwrite(STDERR, "ASN checker disabled, nothing to do.\n");
        exit(0);
    }

    $updated = 0;

    // Обновляем все три ASN-чекера (white/block/captcha).
    $configs = [
        ['listName' => 'whitelist_asn', 'action' => 'ALLOW'],
        ['listName' => 'blacklist_asn', 'action' => 'BLOCK'],
        ['listName' => 'captcha_asn',   'action' => 'CAPTCHA'],
    ];

    foreach ($configs as $params) {
        try {
            $checker = new ASNChecker($config, $logger, $params);
            $reflection = new \ReflectionClass($checker);
            $method = $reflection->getMethod('updateCacheDB');
            $method->setAccessible(true);
            $method->invoke($checker);
            $updated++;
        } catch (\Throwable $e) {
            fwrite(STDERR, "WARN: failed to update {$params['listName']}: " . $e->getMessage() . "\n");
        }
    }

    fwrite(STDOUT, "ASN caches refreshed: {$updated}/3\n");
    exit(0);
} catch (\Throwable $e) {
    fwrite(STDERR, "ERROR: " . $e->getMessage() . "\n");
    fwrite(STDERR, $e->getTraceAsString() . "\n");
    exit(1);
}
