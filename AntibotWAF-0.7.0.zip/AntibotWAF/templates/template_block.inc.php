<?php
/**
 * БЕЗОПАСНОСТЬ: все серверные данные экранируются перед выводом.
 * i18n: все тексты берутся из языкового пакета.
 */
function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

$siteName    = e($_SERVER['SERVER_NAME'] ?? '');
$rayId       = e($t->Profile->RayID ?? '');
$remoteAddr  = e($_SERVER['REMOTE_ADDR'] ?? '');

$langPack = $t->I18n->getPack();
$availableLangs = $t->I18n->getAvailableLangs();
$currentLang = $t->I18n->getCurrentLang();
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';

$blockTitle              = e($langPack['block_title'] ?? 'Attention required!');
$enableCookies           = e($langPack['enable_cookies'] ?? 'Please enable cookies.');
$blockHeadline           = e($langPack['block_headline'] ?? 'Sorry, you have been blocked.');
$unableToAccess          = e($langPack['unable_to_access'] ?? 'You cannot access');
$blockedWhyHeadline      = e($langPack['blocked_why_headline'] ?? 'Why have I been blocked?');
$blockedWhyDetail        = e($langPack['blocked_why_detail'] ?? '');
$blockedResolveHeadline  = e($langPack['blocked_resolve_headline'] ?? 'What can I do to resolve this?');
$blockedResolveDetail    = e($langPack['blocked_resolve_detail'] ?? '');
$clickToReveal           = e($langPack['click_to_reveal'] ?? 'Click to reveal');
$yourIp                  = e($langPack['your_ip'] ?? 'Your IP:');
$rayIdLbl                = e($langPack['ray_id'] ?? 'Ray ID');

$htmlLang = e($langPack['html_lang'] ?? 'en');
$dir = e($langPack['dir'] ?? 'ltr');

// Все языковые пакеты для JS-переключателя.
$allPacksForJs = $t->I18n->getAllPacksForJs();
$currentLang = $t->I18n->getCurrentLang();
?>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="<?= $htmlLang ?>"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="<?= $htmlLang ?>"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="<?= $htmlLang ?>"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="<?= $htmlLang ?>" dir="<?= $dir ?>"> <!--<![endif]-->
<head>
  <title data-i18n="block_title"><?= $blockTitle ?></title>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
  <meta name="robots" content="noindex, nofollow" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
  <meta http-equiv="Pragma" content="no-cache">
  <meta http-equiv="Expires" content="0">
<?php require __DIR__ . '/_block_css.inc.php'; ?>
  <style>
    /* Дополнительные стили для переключателя языков */
    .lang-switcher{margin-top:1.5rem;display:flex;gap:.4rem;flex-wrap:wrap;justify-content:center}
    .lang-btn{display:inline-block;padding:.25rem .55rem;font-size:.75rem;border:1px solid #d9d9d9;border-radius:.25rem;color:#0051c3;text-decoration:none;background:#fff;transition:all .15s ease}
    .lang-btn:hover{background:#f0f0f0;color:#ee730a}
    .lang-btn-active{background:#0051c3;color:#fff;border-color:#0051c3}
    .lang-btn-active:hover{background:#003681;color:#fff}
    @media (prefers-color-scheme:dark){
      .lang-btn{background:#222;color:#fff;border-color:#555}
      .lang-btn:hover{background:#333;color:#ee730a}
      .lang-btn-active{background:#4693ff;color:#1d1d1d;border-color:#4693ff}
    }
  </style>
  <!--[if gte IE 10]><!-->
  <script>
    if (!navigator.cookieEnabled) {
      window.addEventListener('DOMContentLoaded', function () {
        var cookieEl = document.getElementById('cookie-alert');
        if (cookieEl) cookieEl.style.display = 'block';
      })
    }
  </script>
  <!--<![endif]-->
</head>

<body>
  <div id="ni-wrapper">
    <div class="ni-alert ni-alert-error ni-cookie-error" id="cookie-alert" data-translate="enable_cookies" data-i18n="enable_cookies" style="display:none;"><?= $enableCookies ?></div>
    <div id="ni-error-details" class="ni-error-details-wrapper">
      <div class="ni-wrapper ni-header ni-error-overview">
        <h1 data-translate="block_headline" data-i18n="block_headline"><?= $blockHeadline ?></h1>
        <h2 class="ni-subheadline"><span data-translate="unable_to_access" data-i18n="unable_to_access"><?= $unableToAccess ?></span> <?= $siteName ?>
        </h2>
      </div><!-- /.header -->

      <div class="ni-section ni-highlight">
        <div class="ni-wrapper">
          <div class="ni-screenshot-container ni-screenshot-full">
            <span class="ni-no-screenshot error"></span>
          </div>
        </div>
      </div><!-- /.captcha-container -->

      <div class="ni-section ni-wrapper">
        <div class="ni-columns two">
          <div class="ni-column">
            <h2 data-translate="blocked_why_headline" data-i18n="blocked_why_headline"><?= $blockedWhyHeadline ?></h2>
            <p data-translate="blocked_why_detail" data-i18n="blocked_why_detail"><?= $blockedWhyDetail ?></p>
          </div>

          <div class="ni-column">
            <h2 data-translate="blocked_resolve_headline" data-i18n="blocked_resolve_headline"><?= $blockedResolveHeadline ?></h2>
            <p data-translate="blocked_resolve_detail" data-i18n="blocked_resolve_detail"><?= $blockedResolveDetail ?></p>
          </div>
        </div>
      </div><!-- /.section -->

      <div class="ni-error-footer ni-wrapper w-240 lg:w-full py-10 sm:py-4 sm:px-8 mx-auto text-center sm:text-left border-solid border-0 border-t border-gray-300">
        <p class="text-13">
          <span class="ni-footer-item sm:block sm:mb-1"><span data-i18n="ray_id"><?= $rayIdLbl ?></span>: <strong class="font-semibold"><?= $rayId ?></strong></span>
          <span class="ni-footer-separator sm:hidden">&bull;</span>
          <span id="ni-footer-item-ip" class="ni-footer-item hidden sm:block sm:mb-1">
            <span data-i18n="your_ip"><?= $yourIp ?></span>
            <button type="button" id="ni-footer-ip-reveal" class="ni-footer-ip-reveal-btn" data-i18n="click_to_reveal"><?= $clickToReveal ?></button>
            <span class="hidden" id="ni-footer-ip"><?= $remoteAddr ?></span>
            <span class="ni-footer-separator sm:hidden">&bull;</span>
          </span>
        </p>
        <?php
        // Language switcher
        echo $t->I18n->renderLangSwitcher($requestUri);
        ?>
        <script>(function () { function d() { var b = a.getElementById("ni-footer-item-ip"), c = a.getElementById("ni-footer-ip-reveal"); b && "classList" in b && (b.classList.remove("hidden"), c.addEventListener("click", function () { c.classList.add("hidden"); a.getElementById("ni-footer-ip").classList.remove("hidden") } )) }  var a = document; document.addEventListener && a.addEventListener("DOMContentLoaded", d) } )();</script>
      </div><!-- /.error-footer -->

    </div><!-- /#ni-error-details -->
  </div><!-- /#ni-wrapper -->
<script>
var I18N_FULL=<?= json_encode($allPacksForJs, JSON_UNESCAPED_UNICODE) ?>;
var I18N_CURRENT=<?= json_encode($currentLang) ?>;
</script>
<script src="<?= e($t->Config->ANTIBOT_PATH) ?>js/i18n.js"></script>
</body>
</html>
