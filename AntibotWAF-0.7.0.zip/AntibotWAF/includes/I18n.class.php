<?php

namespace WAFSystem;

/**
 * Интернационализация шаблонов капчи и блок-страницы.
 *
 * Поддерживаемые языки: ru, en (по умолчанию), de, fr, pl.
 *
 * Приоритет определения языка:
 *   1. ?lang=xx (только из white-list available)
 *   2. cookie (если ранее выбрали)
 *   3. Accept-Language заголовок
 *   4. default_lang из config.ini
 *   5. 'en' как финальный fallback
 *
 * Переводы хранятся в lang/{code}.php как PHP-массивы.
 * Кешируются в APCu по filemtime (как и другие ресурсы).
 */
class I18n
{
    private static $_instances = null;

    /** @var Config */
    private $Config;

    /** @var string Текущий язык (ru|en|de|fr|pl) */
    private $currentLang = 'en';

    /** @var array Текущий языковой пакет */
    private $pack = [];

    /** @var string[] Доступные языки */
    private $availableLangs = ['en'];

    /** @var string Язык по умолчанию */
    private $defaultLang = 'en';

    /** @var string Имя куки для хранения языка */
    private $cookieName = 'antibot_lang';

    /** @var int Срок действия куки языка (дни) */
    private $cookieDays = 365;

    /** @var bool Использовать Accept-Language для автоопределения */
    private $detectAcceptLanguage = true;

    /** @var bool HeaderProxy для определения HTTPS при установке secure-куки */
    private $headerProxy;

    private function __construct(Config $config)
    {
        $this->Config = $config;

        $this->defaultLang = strtolower((string)$config->init('i18n', 'default_lang', 'en', 'ru|en|de|fr|pl — язык по умолчанию'));
        $available = $config->init('i18n', 'available', 'ru,en,de,fr,pl', 'Список доступных языков через запятую');
        if (is_string($available)) {
            $this->availableLangs = array_filter(array_map('trim', explode(',', $available)), function ($v) {
                return $v !== '';
            });
        } elseif (is_array($available)) {
            $this->availableLangs = $available;
        }
        // Гарантируем, что default есть в available
        if (!in_array($this->defaultLang, $this->availableLangs, true)) {
            $this->availableLangs[] = $this->defaultLang;
        }

        $this->cookieName = (string)$config->init('i18n', 'cookie_name', $this->cookieName, 'имя куки для хранения выбранного языка');
        $this->cookieDays = (int)$config->init('i18n', 'cookie_days', $this->cookieDays, 'срок действия куки языка');
        $this->detectAcceptLanguage = (bool)$config->init('i18n', 'detect_accept_language', $this->detectAcceptLanguage, 'использовать заголовок Accept-Language для автоопределения');

        $this->headerProxy = new HeaderProxy($config);

        $this->currentLang = $this->detectLanguage();
        $this->pack = $this->loadPack($this->currentLang);
    }

    public static function getInstance(Config $config): self
    {
        if (is_null(self::$_instances)) {
            self::$_instances = new self($config);
        }
        return self::$_instances;
    }

    public function getCurrentLang(): string
    {
        return $this->currentLang;
    }

    public function getAvailableLangs(): array
    {
        return $this->availableLangs;
    }

    public function getPack(): array
    {
        return $this->pack;
    }

    /**
     * Возвращает JS-пак (подмножество ключей, нужных в браузере).
     */
    public function getJsPack(): array
    {
        return [
            'html_lang'        => $this->pack['html_lang'] ?? 'en',
            'dir'              => $this->pack['dir'] ?? 'ltr',
            'instruction'      => $this->pack['instruction'] ?? 'If you are human, click the {color} checkbox',
            'verifying_text'   => $this->pack['verifying_text'] ?? 'Verifying…',
            'fail_text'        => $this->pack['fail_text'] ?? 'Failure',
            'having_trouble'   => $this->pack['having_trouble'] ?? 'Having trouble?',
            'stuck_here'       => $this->pack['stuck_here'] ?? 'Stuck here?',
            'send_feedback'    => $this->pack['send_feedback'] ?? 'Send Feedback',
            'refresh'          => $this->pack['refresh'] ?? 'Refresh',
            'colors'           => $this->pack['colors'] ?? ['blue' => 'blue', 'green' => 'green', 'red' => 'red'],
        ];
    }

    /**
     * Перевод строки по ключу. Опционально подставляет {placeholders}.
     */
    public function t(string $key, array $params = []): string
    {
        $value = $this->pack[$key] ?? $key;
        if (!empty($params)) {
            foreach ($params as $k => $v) {
                $value = str_replace('{' . $k . '}', (string)$v, $value);
            }
        }
        return $value;
    }

    /**
     * Определяет язык по приоритетам.
     */
    private function detectLanguage(): string
    {
        // 1. ?lang=xx
        $getLang = isset($_GET['lang']) ? strtolower((string)$_GET['lang']) : '';
        if ($getLang !== '' && in_array($getLang, $this->availableLangs, true)) {
            $this->setLangCookie($getLang);
            return $getLang;
        }

        // 2. cookie
        if (isset($_COOKIE[$this->cookieName])) {
            $cookieLang = strtolower((string)$_COOKIE[$this->cookieName]);
            if (in_array($cookieLang, $this->availableLangs, true)) {
                return $cookieLang;
            }
        }

        // 3. Accept-Language
        if ($this->detectAcceptLanguage && !empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $lang = $this->parseAcceptLanguage($_SERVER['HTTP_ACCEPT_LANGUAGE']);
            if ($lang !== null && in_array($lang, $this->availableLangs, true)) {
                return $lang;
            }
        }

        // 4. default
        if (in_array($this->defaultLang, $this->availableLangs, true)) {
            return $this->defaultLang;
        }

        // 5. финальный fallback
        return 'en';
    }

    /**
     * Парсит Accept-Language: "ru,en;q=0.9,de;q=0.8" → ['ru','en','de']
     */
    private function parseAcceptLanguage(string $header): ?string
    {
        $accepted = [];
        $parts = explode(',', $header);
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') continue;
            // Формат: "ru" или "ru;q=0.9"
            if (preg_match('/^([a-zA-Z]{2})(?:-[a-zA-Z]+)?(?:;q=([0-9.]+))?$/', $part, $m)) {
                $lang = strtolower($m[1]);
                $q = isset($m[2]) ? (float)$m[2] : 1.0;
                $accepted[] = ['lang' => $lang, 'q' => $q];
            }
        }
        // Сортируем по q убыванию.
        usort($accepted, function ($a, $b) {
            return $b['q'] <=> $a['q'];
        });
        foreach ($accepted as $a) {
            if (in_array($a['lang'], $this->availableLangs, true)) {
                return $a['lang'];
            }
        }
        return null;
    }

    private function setLangCookie(string $lang): void
    {
        setcookie($this->cookieName, $lang, [
            'expires'  => time() + $this->cookieDays * 86400,
            'path'     => '/',
            'httponly' => true,
            'secure'   => $this->headerProxy->isHttps(),
            'samesite' => 'Lax',
        ]);
        $_COOKIE[$this->cookieName] = $lang;
    }

    /**
     * Загружает языковый пакет с APCu-кешем.
     */
    private function loadPack(string $lang): array
    {
        $file = $this->Config->BasePath . 'lang/' . $lang . '.php';
        if (!is_file($file)) {
            // Fallback на английский.
            $file = $this->Config->BasePath . 'lang/en.php';
            if (!is_file($file)) {
                // Абсолютный фолбэк — пустой пакет.
                return ['html_lang' => 'en', 'dir' => 'ltr'];
            }
        }

        $mtime = filemtime($file);
        $cacheKey = 'antibot_i18n_' . md5($file) . '_' . $mtime;

        if (function_exists('apcu_enabled') && apcu_enabled()) {
            $cached = apcu_fetch($cacheKey);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $pack = include $file;
        if (!is_array($pack)) {
            $pack = [];
        }

        if (function_exists('apcu_enabled') && apcu_enabled()) {
            apcu_store($cacheKey, $pack, 3600);
        }

        return $pack;
    }

    /**
     * Возвращает HTML для переключателя языков.
     *
     * БЕЗОПАСНОСТЬ/UX: кнопки вместо ссылок. Переключение делается
     * JS-ом без перезагрузки страницы — это критично, потому что
     * перезагрузка обрывает JS-проверку (FPS, fingerprint) и в некоторых
     * конфигурациях сайта может пропустить antibot (если основной index.php
     * не подключает antibot для URL с ?lang=).
     */
    public function renderLangSwitcher(string $currentUri): string
    {
        $html = '<div class="lang-switcher" role="navigation" aria-label="Language">';
        foreach ($this->availableLangs as $code) {
            $label = strtoupper($code);
            $isActive = $code === $this->currentLang;
            $class = 'lang-btn' . ($isActive ? ' lang-btn-active' : '');
            $html .= sprintf(
                '<button type="button" class="%s" data-lang="%s" lang="%s">%s</button>',
                htmlspecialchars($class, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($code, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($label, ENT_QUOTES, 'UTF-8')
            );
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Возвращает массив всех языковых пакетов для передачи в JS.
     * Используется переключателем языка на стороне браузера.
     */
    public function getAllPacksForJs(): array
    {
        $result = [];
        foreach ($this->availableLangs as $code) {
            $result[$code] = $this->loadPack($code);
        }
        return $result;
    }

    /**
     * Строит URL с ?lang=xx (сохраняя остальные query-параметры).
     * Сохранён для обратной совместимости, но в текущей реализации
     * не используется — переключатель работает через JS.
     */
    private function buildLangUrl(string $uri, string $lang): string
    {
        $parsed = parse_url($uri);
        $path = $parsed['path'] ?? '/';
        parse_str($parsed['query'] ?? '', $query);
        $query['lang'] = $lang;
        return $path . '?' . http_build_query($query);
    }
}
