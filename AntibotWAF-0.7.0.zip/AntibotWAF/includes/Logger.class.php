<?php

namespace WAFSystem;

/**
 * Логирование посещений.
 *
 * БЕЗОПАСНОСТЬ:
 * - Путь к лог-файлу валидируется через Config::resolveSafePath().
 * - Все user-controlled поля (UA, Referer, URI, IP) очищаются от
 *   управляющих символов (\r, \n, \t) перед записью — защита от log injection.
 *
 * ПРОИЗВОДИТЕЛЬНОСТЬ:
 * - Записи буферизуются в памяти на протяжении запроса и сбрасываются
 *   одной операцией flock+fwrite в register_shutdown_function — это
 *   убирает bottleneck "flock на каждую строку" под нагрузкой.
 */
class Logger
{
    private $config;
    private $profile;

    private $logBasePath;
    private $logFile;
    private $debugEnabled;

    /** @var string[] Буфер накопленных записей текущего запроса */
    private $buffer = [];
    /** @var bool Флаг, что shutdown-handler уже зарегистрирован */
    private $shutdownRegistered = false;

    public function __construct(Config $config, Profile $profile)
    {
        $this->config = $config;
        $this->profile = $profile;

        $this->config->init('main', 'debug', true);
        $this->config->init('logs', 'log_file', 'logs/antibot.log');
        $this->config->init('logs', 'max_size', 10, 'Максимальный размер, MB');
        $this->config->init('logs', 'rotate', 7, 'Количество файлов ротации');

        $this->debugEnabled = $this->config->get('main', 'debug', true);

        $logfile = $this->config->get('logs', 'log_file', 'logs/antibot.log');
        if (!is_string($logfile) || $logfile === '') {
            $logfile = 'logs/antibot.log';
            $this->config->set('logs', 'log_file', $logfile);
        }

        // БЕЗОПАСНОСТЬ: путь валидируется на path traversal.
        try {
            $this->logFile = $this->config->resolveSafePath($logfile);
        } catch (\RuntimeException $e) {
            // На случай если путь невалиден — фолбэк на безопасный дефолт.
            $this->logFile = $this->config->BasePath . 'logs/antibot.log';
        }

        $this->validateLogFile();
    }

    public function logMessage($message)
    {
        if (!$this->debugEnabled) {
            return;
        }

        // БЕЗОПАСНОСТЬ: очищаем от управляющих символов — защита от log injection.
        $message = $this->sanitizeForLog($message);

        $this->buffer[] = $this->formatLogEntry($message);

        // Регистрируем сброс один раз.
        if (!$this->shutdownRegistered) {
            $this->shutdownRegistered = true;
            register_shutdown_function([$this, 'flush']);
        }
    }

    public function log($message, $context = [])
    {
        $fullMessage = $message;
        if (!empty($context)) {
            // Контекст тоже чистим — в нём могут быть user-controlled данные.
            $cleanContext = array_map([$this, 'sanitizeForLog'], $context);
            $fullMessage .= " | " . json_encode($cleanContext, JSON_UNESCAPED_UNICODE);
        }
        $this->logMessage($fullMessage);
    }

    /**
     * Сбрасывает накопленный буфер в файл одной операцией flock.
     * Вызывается автоматически в register_shutdown_function,
     * но может вызываться и явно (например, перед showCaptcha/showBlockPage).
     */
    public function flush(): void
    {
        if (empty($this->buffer)) {
            return;
        }

        // Сливаем буфер в локальную переменную и очищаем — на случай
        // если в процессе записи кто-то ещё вызовет log().
        $payload = implode('', $this->buffer);
        $this->buffer = [];

        if (is_file($this->logFile) && !is_writable($this->logFile)) {
            error_log("The logfile is not writable: " . $this->logFile);
            return;
        }

        $this->writeToFile($this->logFile, $payload);
    }

    private function formatLogEntry($message)
    {
        // IP и RayID уже являются валидными hex/IP-строками, но на всякий случай
        // пропускаем через sanitize тоже.
        $rayId = $this->sanitizeForLog($this->profile->RayID);
        $ip = $this->sanitizeForLog($this->profile->IP);
        $message = $this->sanitizeForLog($message);

        return sprintf(
            "%s %s %s %s\n",
            date('Y-m-d H:i:s'),
            $rayId,
            $ip,
            $message
        );
    }

    private function writeToFile($filePath, $content)
    {
        $retry = 0;
        $maxRetries = 3;

        while ($retry < $maxRetries) {
            if ($handle = @fopen($filePath, 'a')) {
                if (flock($handle, LOCK_EX)) {
                    fwrite($handle, $content);
                    flock($handle, LOCK_UN);
                    fclose($handle);
                    return;
                }
                fclose($handle);
            }
            $retry++;
            usleep(100000);
        }

        error_log("Failed to write log after {$maxRetries} attempts: " . $filePath);
    }

    /**
     * Удаляет CR/LF/TAB и другие управляющие символы — защита от log injection.
     */
    private function sanitizeForLog($value)
    {
        if (!is_string($value)) {
            return $value;
        }
        // Заменяем \r \n \t и другие control chars на пробел.
        return preg_replace('/[\x00-\x1F\x7F]/', ' ', $value);
    }

    private function validateLogFile()
    {
        if (file_exists($this->logFile) && !is_writable($this->logFile)) {
            throw new \RuntimeException("Main log file is not writable: " . $this->logFile);
        }

        $logDir = dirname($this->logFile);
        if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
            throw new \RuntimeException("Failed to create log directory: " . $logDir);
        }
    }

    /**
     * Проверяет и выполняет ротацию логов при необходимости.
     * ВАЖНО: ротация должна запускаться из cron, не из запроса (Этап 3).
     */
    public function rotateIfNeeded()
    {
        $maxSizeMB = $this->config->get('logs', 'max_size', 10);
        $rotateCount = $this->config->get('logs', 'rotate', 5);

        if (!is_file($this->logFile) || filesize($this->logFile) < ($maxSizeMB * 1024 * 1024)) {
            return;
        }

        $this->rotateLogs($rotateCount);
        $this->logMessage("Log rotation completed. Rotated files: {$rotateCount}");
    }

    private function rotateLogs($rotateCount)
    {
        $tempFile = $this->logFile . '.temp_' . mt_rand();
        if (!rename($this->logFile, $tempFile)) {
            error_log("Failed to rename log file for rotation");
            return;
        }

        touch($this->logFile);
        chmod($this->logFile, 0640);

        $this->processArchives($tempFile, $rotateCount);
    }

    private function processArchives($sourceFile, $rotateCount)
    {
        $newArchive = $this->compressFile($sourceFile);
        if (!$newArchive) {
            unlink($sourceFile);
            return;
        }

        $oldestArchive = $this->logFile . '.' . $rotateCount . '.gz';
        if (file_exists($oldestArchive)) {
            unlink($oldestArchive);
        }

        for ($i = $rotateCount - 1; $i >= 1; $i--) {
            $current = $this->logFile . '.' . $i . '.gz';
            $new = $this->logFile . '.' . ($i + 1) . '.gz';
            if (file_exists($current)) {
                rename($current, $new);
            }
        }

        rename($newArchive, $this->logFile . '.1.gz');

        if (file_exists($sourceFile)) {
            unlink($sourceFile);
        }
    }

    private function compressFile($sourceFile)
    {
        if (!function_exists('gzopen')) {
            error_log("Zlib extension not available");
            return false;
        }

        $gzFile = $sourceFile . '.gz';
        $mode = 'wb9';

        $fp_out = gzopen($gzFile, $mode);
        if (!$fp_out) {
            error_log("Cannot create gzip file: " . $gzFile);
            return false;
        }

        $fp_in = fopen($sourceFile, 'rb');
        if (!$fp_in) {
            gzclose($fp_out);
            unlink($gzFile);
            error_log("Cannot read source file: " . $sourceFile);
            return false;
        }

        while (!feof($fp_in)) {
            gzwrite($fp_out, fread($fp_in, 4096));
        }

        fclose($fp_in);
        gzclose($fp_out);

        return $gzFile;
    }
}
