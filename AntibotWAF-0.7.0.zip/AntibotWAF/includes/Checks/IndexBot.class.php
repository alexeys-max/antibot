<?php

namespace WAFSystem;

use Exception;

/**
 * Проверка IP на индексирующего бота через обратный DNS.
 *
 * ПРОИЗВОДИТЕЛЬНОСТЬ:
 * - UA-prefilter: gethostbyaddr() делается ТОЛЬКО если User-Agent похож
 *   на поискового бота (bot/spider/crawl/slurp). Ранее DNS-запрос делался
 *   для КАЖДОГО нового посетителя, что при cache miss могло блокировать
 *   FPM-worker на 5-10 секунд.
 * - DnsCache может работать через Redis (если включён в config.ini) —
 *   кеш-хит за <1 мс вместо 0.5-2 мс для файла.
 */
class IndexBot extends ListBase
{
    public $listName = 'indexbot_rules';
    public $enabled = true;

    private $Profile;
    private $Dns;
    private $modulName = 'indexbot_checker';

    /** Быстрая проверка UA на признаки бота */
    private $botUaPattern = '/(bot|spider|crawl|slurp|search|fetch|index|archiver|preview|snippet|reader|parser|checker|monitor|webcapture)/i';

    public function __construct(Config $config, Profile $profile, Logger $logger)
    {
        $this->Logger = $logger;
        $this->Profile = $profile;

        $this->enabled = $config->init($this->modulName, 'enabled', $this->enabled, 'пропускать поисковых ботов');

        $file = ltrim($config->get($this->modulName, $this->listName, ''), "/\\");
        if (empty($file)) {
            $file = "lists/" . $this->listName;
            $config->set($this->modulName, $this->listName, $file);
        }

        $this->Dns = $this->createDnsCache($config);
        parent::__construct($file, $config, $logger);
    }

    /**
     * Создаёт DnsCache с драйвером из конфига (file или redis).
     *
     * При переключении на redis автоматически очищает файловый кеш cache/dns/,
     * чтобы не оставалось мёртвых файлов.
     */
    private function createDnsCache(Config $config): \DnsCache\DnsCache
    {
        $driverType = strtolower((string)$config->get('dns_cache', 'driver', 'file'));
        $cacheDir = $config->CachePath . 'dns';
        $ttl = (int)$config->get('dns_cache', 'ttl', 86400);

        if ($driverType === 'redis') {
            $redisHost = (string)$config->get('dns_cache', 'redis_host', '127.0.0.1');
            $redisPort = (int)$config->get('dns_cache', 'redis_port', 6379);
            $redisPrefix = (string)$config->get('dns_cache', 'redis_prefix', 'dns:');

            try {
                $driver = new \DnsCache\RedisCacheDriver($redisHost, $redisPort, $redisPrefix);
                if ($driver->isAvailable()) {
                    // Автоочистка файлового кеша при переключении на redis.
                    $this->clearFileDnsCache($cacheDir);
                    return new \DnsCache\DnsCache($driver, 3600, $ttl);
                }
            } catch (\Exception $e) {
                // Fallback на файловый кеш.
                $this->Logger->log("Redis DnsCache unavailable, falling back to file: " . $e->getMessage());
            }
        }

        $driver = new \DnsCache\FileCacheDriver($cacheDir);
        return new \DnsCache\DnsCache($driver, 3600, $ttl);
    }

    /**
     * Рекурсивно удаляет все .json файлы из файлового DNS-кеша.
     * Вызывается при переключении driver=redis, чтобы не оставлять мёртвые файлы.
     */
    private function clearFileDnsCache(string $cacheDir): void
    {
        if (!is_dir($cacheDir)) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($cacheDir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );
        $count = 0;
        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'json') {
                @unlink($file->getPathname());
                $count++;
            }
        }
        if ($count > 0) {
            $this->Logger->log("Cleared {$count} stale DNS cache files (switched to redis driver)");
        }
    }

    /**
     * Проверяет IP на индексирующего бота.
     *
     * Сначала делаем быстрый UA-prefilter. Если UA не похож на бота —
     * пропускаем DNS-запрос и возвращаем false (считаем, что это не бот).
     */
    public function Checking($client_ip)
    {
        // UA-prefilter: пропускаем только если UA содержит признаки бота.
        $ua = $this->Profile->UserAgent;
        if ($ua === '' || !preg_match($this->botUaPattern, $ua)) {
            return false;
        }

        try {
            $hostname = $this->Dns->getHostByAddr($client_ip);
        } catch (\Exception $e) {
            $this->Logger->log($e->getMessage(), [static::class]);
            throw new Exception($e->getMessage());
        }
        $this->Logger->log('PTR: ' . $hostname);
        return $this->isListed($hostname);
    }

    protected function validate($domain)
    {
        $pattern = '/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/';
        return (bool)preg_match($pattern, $domain);
    }

    protected function createDefaultFileContent()
    {
        $defaultContent = <<<EOT
# {$this->listName}
# Список PTR индексирующих роботов. Указывается домен первого уровня.

yandex.ru
googlebot.com
google.com
googlezip.net   # Chrome Privacy Preserving Prefetch Proxy https://foxi.biz/viewtopic.php?id=294
yandex.ru
yandex.net
yandex.com
msn.com         # Поисковик bing.com +http://www.bing.com/bingbot.htm
bing.com        # Поисковик bing.com +http://www.bing.com/bingbot.htm
msedge.net      # Запросы Edge
petalsearch.com # Сервисы Huawei +https://webmaster.petalsearch.com/site/petalbot
apple.com       # http://www.apple.com/go/applebot
baidu.com       # Китайский поисковик +http://www.baidu.com/search/spider.html
baidu.jp        # Китайский поисковик +http://www.baidu.com/search/spider.html
telegram.org    # Телеграм бот, для чтения мета
odnoklassniki.ru # Для чтения метатегов
mail.ru         # Сервисы mail.ru, vk.com
googleusercontent.com # Discord +https://discordapp.com
letsencrypt.org # Бесплатные SSL-сертификаты
duckduckgo.com  # DuckDuckGo-Favicons-Bot
w3.org # https://validator.w3.org/

EOT;
        return $defaultContent;
    }

    protected function Comparison($value1, $hostname)
    {
        $reg = str_replace('.', '\.', $value1);
        mb_regex_encoding('UTF-8');

        if (preg_match("/\.$reg$/i", $hostname, $match) === 1) {
            try {
                $resolvedRecords = $this->Dns->getRecord($hostname, $this->Profile->isIPv6 ? DNS_AAAA : DNS_A);
            } catch (\Exception $e) {
                $this->Logger->log($e->getMessage(), [static::class]);
                throw new Exception($e->getMessage());
            }

            if (!empty($resolvedRecords)) {
                foreach ($resolvedRecords as $record) {
                    if ($this->Profile->isIPv6) {
                        if (isset($record['ipv6']) && inet_pton($record['ipv6']) === inet_pton($this->Profile->IP)) {
                            return true;
                        }
                    } else {
                        if (isset($record['ip']) && inet_pton($record['ip']) === inet_pton($this->Profile->IP)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        return false;
    }

    /**
     * Используется в Api::BlockIP — проверяет, индексирующий ли это бот
     * (без UA-prefilter, чтобы корректно сработало для блокировки).
     */
    public function isIndexbot($client_ip): bool
    {
        try {
            return $this->Checking($client_ip);
        } catch (\Exception $e) {
            return false;
        }
    }
}
