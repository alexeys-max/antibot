<?php
namespace WAFSystem;

class WhiteListIP extends ListBase
{
    public $listName = 'whitelist_ip';
    public $enabled = true;

    private $modulName = 'ip_checker';

    public function __construct(Config $config, Logger $logger)
    {
        $this->enabled = $config->init($this->modulName, 'enabled', $this->enabled);

        $file = ltrim($config->get($this->modulName, $this->listName, ''), "/\\");
        if (empty($file)) {
            $file = "lists/" . $this->listName;
            $config->set($this->modulName, $this->listName, $file, 'белый список');
        }

        parent::__construct($file, $config, $logger);
    }

    /**
     * Срабатывает после создания пустого файла whitelist_ip.
     *
     * БЕЗОПАСНОСТЬ: используем gethostname() (серверный hostname) вместо
     * $_SERVER['HTTP_HOST'] (клиентский заголовок, полностью контролируется
     * атакующим). Ранее это позволяло первому посетителю свежей установки
     * отравить whitelist, отправив произвольный Host: заголовок.
     */
    protected function eventInitListFile()
    {
        $hostname = gethostname();
        if ($hostname === false || $hostname === '') {
            return;
        }

        $resolvedRecords = @dns_get_record($hostname, DNS_A + DNS_AAAA);

        if (!empty($resolvedRecords)) {
            $this->Logger->log("Adding IP addresses of host {$hostname} to exceptions");
            foreach ($resolvedRecords as $record) {
                if ($record['type'] == 'A' || $record['type'] == 'AAAA') {
                    $ip = $record['type'] == 'AAAA' ? $record['ipv6'] : $record['ip'];
                    if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                        $this->add($ip, $hostname);
                    }
                }
            }
        }
    }

    protected function createDefaultFileContent()
    {
        $defaultContent = <<<EOT
# {$this->listName}
# Белый список IP-адресов
# Формат:
#  IP # комментарий
#  IP/mask # комментарий
#  IP-IP # комментарий

EOT;
        return $defaultContent;
    }

    protected function validate($value)
    {
        return filter_var($value, FILTER_VALIDATE_IP) !== false;
    }

    protected function Comparison($value1, $value2)
    {
        return \Utility\Network::isInRange($value2, $value1);
    }
}
