<?php

namespace WAFSystem;

/**
 * Профиль посетителя: IP, UA, RayID, секрет маркера.
 *
 * БЕЗОПАСНОСТЬ:
 * - Секрет маркера и RayID вычисляются через hash_hmac('sha256', ...) с
 *   32-байтным серверным секретом, а не md5() с 5-11 hex salt.
 * - Значение маркер-куки валидируется сервером (HMAC), а не только по
 *   факту наличия (см. Marker::isValid()).
 * - Секрет генерируется через random_bytes(32) при первом запуске.
 */
class Profile
{
    private $Config;

    private static $_instances = null;

    /** @var string 64-символьный hex-секрет, загружается из config.ini */
    private $markerSecret = '';

    public $RayID;
    public $RayIDSecret;
    public $Host;
    public $IP;
    public $HttpVersion;
    public $UserAgent;
    public $isIPv6;
    public $Referer;
    public $REQUEST_URI;
    public $FingerPrint;
    public $isMobile;
    public $FPS;

    private function __construct(Config $config)
    {
        $this->Config = $config;
        $HeadProxy = new HeaderProxy($config);

        $this->Host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $this->IP = $HeadProxy->getIPAddr();
        $this->HttpVersion = $HeadProxy->getHttpVersion();
        $this->UserAgent = isset($_SERVER['HTTP_USER_AGENT']) ? mb_substr($_SERVER['HTTP_USER_AGENT'], 0, 512) : '';
        $this->Referer = isset($_SERVER['HTTP_REFERER']) ? mb_substr($_SERVER['HTTP_REFERER'], 0, 512) : '';
        $this->REQUEST_URI = isset($_SERVER['REQUEST_URI']) ? mb_substr($_SERVER['REQUEST_URI'], 0, 512) : '';

        $this->isIPv6 = filter_var($this->IP, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
        $this->isMobile = isset($_SERVER['HTTP_SEC_CH_UA_MOBILE']) ? ($_SERVER['HTTP_SEC_CH_UA_MOBILE'] === '?1' ? true : false) : null;

        // БЕЗОПАСНОСТЬ: секрет — 64 hex-символа (256 бит энтропии).
        // Генерируется один раз при первом запуске, сохраняется в config.ini.
        $existingSecret = $config->get('cookie', 'cookie_name', '');
        if (!is_string($existingSecret) || !preg_match('/^[a-f0-9]{64}$/', $existingSecret)) {
            $newSecret = bin2hex(random_bytes(32));
            $config->set('cookie', 'cookie_name', $newSecret, 'Секрет маркера (256 бит). Не меняйте вручную без необходимости сброса всех маркеров.');
            $this->markerSecret = $newSecret;
        } else {
            $this->markerSecret = $existingSecret;
        }

        $this->RayID = $this->getRayID();
        $this->RayIDSecret = $this->getRayIDSecret();
    }

    public static function getInstance(Config $config)
    {
        if (is_null(self::$_instances)) {
            self::$_instances = new self($config);
        }
        return self::$_instances;
    }

    /**
     * Возвращает серверный секрет для HMAC-подписей.
     */
    public function getMarkerSecret(): string
    {
        return $this->markerSecret;
    }

    /**
     * Генерирует случайный 64-символьный hex-ключ.
     */
    public function genKey(): string
    {
        return bin2hex(random_bytes(32));
    }

    /**
     * RayID — публичный идентификатор сессии для лога и блок-страницы.
     * HMAC от IP+UA с секретом, обрезанный до 16 hex (64 бита) — достаточно
     * для уникальности и непредсказуемости без раскрытия секрета.
     */
    private function getRayID(): string
    {
        return substr(hash_hmac('sha256', $this->IP . '|' . $this->UserAgent, $this->markerSecret), 0, 16);
    }

    /**
     * RayIDSecret — имя cookie-маркера. HMAC от IP+UA с секретом,
     * обрезанный до 32 hex (128 бит) — имя не предсказуемо без секрета.
     */
    private function getRayIDSecret(): string
    {
        return substr(hash_hmac('sha256', $this->IP . '|' . $this->UserAgent, $this->markerSecret), 16, 32);
    }

    /**
     * Вычисляет ожидаемое значение cookie-маркера для текущего посетителя.
     * Используется Marker::isValid() для проверки присланной куки.
     *
     * Формат: <randomNonce>.<hmac(IP|UA|nonce|expires)>
     */
    public function computeMarkerValue(int $expires): string
    {
        $nonce = bin2hex(random_bytes(16));
        $payload = $this->IP . '|' . $this->UserAgent . '|' . $nonce . '|' . $expires;
        $sig = hash_hmac('sha256', $payload, $this->markerSecret);
        return $nonce . '.' . $expires . '.' . $sig;
    }

    /**
     * Проверяет, что значение cookie-маркера корректно подписано и не истекло.
     */
    public function verifyMarkerValue(string $value): bool
    {
        if ($value === '' || strpos($value, '.') === false) {
            return false;
        }
        $parts = explode('.', $value, 3);
        if (count($parts) !== 3) {
            return false;
        }
        [$nonce, $expiresStr, $sig] = $parts;
        if (!ctype_xdigit($nonce) || strlen($nonce) !== 32) {
            return false;
        }
        if (!ctype_digit($expiresStr)) {
            return false;
        }
        $expires = (int)$expiresStr;
        // Допускаем небольшое окно (1 час) после истечения — на случай рассинхрона часов.
        if ($expires < time() - 3600) {
            return false;
        }
        $payload = $this->IP . '|' . $this->UserAgent . '|' . $nonce . '|' . $expires;
        $expected = hash_hmac('sha256', $payload, $this->markerSecret);
        return hash_equals($expected, $sig);
    }
}
