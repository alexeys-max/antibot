<?php

namespace WAFSystem;

/**
 * Подключение шаблонов страниц капчи и блокировки.
 *
 * БЕЗОПАСНОСТЬ: все пользовательские данные (SERVER_NAME, IP, RayID и т.д.)
 * экранируются htmlspecialchars() в самих шаблонах.
 */
class Template
{
    private $Config;
    private $Profile;
    private $Logger;
    /** @var I18n|null */
    private $I18n = null;

    private $metrika = '';
    private $utm_referrer = false;
    private $save_referer = false;

    public function __construct(Config $config, Profile $profile, Logger $logger)
    {
        $this->Config = $config;
        $this->Profile = $profile;
        $this->Logger = $logger;

        $this->Config->init('main', 'header404', false, 'отдает на заглушку 404 заголовок');
        $this->Config->init('main', 'metrika', $this->metrika, 'Код Яндекс Метрики. Можете установить свой код или оставить текущий для сбора данных о ботах нашими специалистами. Пустая строка отключает показ метрики');
        $this->utm_referrer = $this->Config->init('main', 'utm_referrer', $this->utm_referrer, 'вкл/выкл');
        $this->save_referer = $this->Config->init('main', 'save_referer', $this->save_referer, 'вкл/выкл сохраненние referer в localStorage');
    }

    /**
     * Инъекция I18n — вызывается из WAFSystem после создания Template.
     */
    public function setI18n(I18n $i18n): void
    {
        $this->I18n = $i18n;
    }

    public function __get($name)
    {
        if ($name === 'I18n') {
            return $this->I18n;
        }
        if ($name === 'utm_referrer') {
            return $this->utm_referrer;
        }
        if ($name === 'save_referer') {
            return $this->save_referer;
        }
        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);
        trigger_error("Undefined property via __get(): {$name} in {$trace[0]['file']} on line {$trace[0]['line']}", E_USER_NOTICE);
        return null;
    }

    public function showCaptcha()
    {
        if ($this->Config->get('main', 'header404')) {
            header("HTTP/1.0 404 Not Found");
        }
        header('X-Robots-Tag: noindex');
        header('Pragma: no-cache');
        header('Expires: Thu, 18 Aug 1994 05:00:00 GMT');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

        $this->Logger->log("Displaying the verification page");

        // Подготавливаем переменные для шаблона.
        $t = $this; // чтобы в шаблоне использовать $t->Config, $t->Profile, $t->I18n
        $langPack = $this->I18n ? $this->I18n->getPack() : null;
        $availableLangs = $this->I18n ? $this->I18n->getAvailableLangs() : [];
        $currentLang = $this->I18n ? $this->I18n->getCurrentLang() : 'en';

        require $this->Config->BasePath . "templates/template.inc.php";
        exit;
    }

    public function showBlockPage()
    {
        header("HTTP/1.0 403 Forbidden");
        header('X-Robots-Tag: noindex');
        header('Pragma: no-cache');
        header('Expires: Thu, 18 Aug 1994 05:00:00 GMT');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        $this->Logger->log("Display the blocking page");

        $t = $this;
        $langPack = $this->I18n ? $this->I18n->getPack() : null;
        $availableLangs = $this->I18n ? $this->I18n->getAvailableLangs() : [];
        $currentLang = $this->I18n ? $this->I18n->getCurrentLang() : 'en';

        require $this->Config->BasePath . "templates/template_block.inc.php";
        exit;
    }
}
