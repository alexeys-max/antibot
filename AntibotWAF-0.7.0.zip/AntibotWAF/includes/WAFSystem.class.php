<?php
/*
 * @author EgorNiKO <niko_egor@mail.ru>
 * @repository https://github.com/githubniko/antibot
 *
 * @copyright Copyright (c) 2025, EgorNiKO. All rights reserved.
 * @license MIT License
 */

namespace WAFSystem;

/**
 * Главный оркестратор WAF.
 *
 * ПРОИЗВОДИТЕЛЬНОСТЬ:
 * - Компоненты создаются LAZY (через __get), только при первом обращении.
 *   На "счастливом пути" (валидный маркер) создание 23 компонентов
 *   пропускается — экономия 2-5 мс на запрос.
 * - Config/Logger/Profile/Marker/Template/I18n создаются eagerly — они
 *   нужны в любом сценарии.
 */
class WAFSystem
{
    public $enabled = true;

    public $Config;
    public $Logger;
    public $Profile;
    public $Marker;
    public $Template;
    public $I18n;

    /** @var array Кеш созданных lazy-компонентов */
    private $lazyComponents = [];

    private static $lazyMap = [
        'WhiteListIP'       => [WhiteListIP::class, 'createWhiteListIP'],
        'BlackListIP'       => [BlackListIP::class, 'createBlackListIP'],
        'UserAgentChecker'  => [UserAgentChecker::class, 'createUserAgentChecker'],
        'UserAgentCaptcha'  => [UserAgentChecker::class, 'createUserAgentCaptcha'],
        'UserAgentBlock'    => [UserAgentChecker::class, 'createUserAgentBlock'],
        'RequestAllow'      => [RequestChecker::class, 'createRequestAllow'],
        'RequestBlock'      => [RequestChecker::class, 'createRequestBlock'],
        'RequestCaptcha'    => [RequestChecker::class, 'createRequestCaptcha'],
        'IndexBot'          => [IndexBot::class, 'createIndexBot'],
        'TorChecker'        => [TorChecker::class, 'createTorChecker'],
        'RefererCaptcha'    => [RefererChecker::class, 'createRefererCaptcha'],
        'RefererAllow'      => [RefererChecker::class, 'createRefererAllow'],
        'RefererBlock'      => [RefererChecker::class, 'createRefererBlock'],
        'FingerPrint'       => [FingerPrint::class, 'createFingerPrint'],
        'GrayList'          => [GrayList::class, 'createGrayList'],
        'HTTPChecker'       => [HTTPChecker::class, 'createHTTPChecker'],
        'MobileChecker'     => [MobileChecker::class, 'createMobileChecker'],
        'IFrameChecker'     => [IFrameChecker::class, 'createIFrameChecker'],
        'ASNWhite'          => [ASNChecker::class, 'createASNWhite'],
        'ASNBlock'          => [ASNChecker::class, 'createASNBlock'],
        'ASNCaptcha'        => [ASNChecker::class, 'createASNCaptcha'],
        'FPSChecker'        => [FPSChecker::class, 'createFPSChecker'],
    ];

    public function __construct()
    {
        $this->initializeCoreComponents();
    }

    private function initializeCoreComponents()
    {
        $this->Config = Config::getInstance();

        # вкл/выкл защиты
        $this->enabled = $this->Config->init('main', 'enabled', $this->enabled, 'вкл/выкл');
        if (!$this->enabled) return;

        $this->Profile = Profile::getInstance($this->Config);
        $this->Logger = new Logger($this->Config, $this->Profile);
        $this->Marker = new Marker($this->Config, $this->Profile, $this->Logger);
        $this->Template = new Template($this->Config, $this->Profile, $this->Logger);
        $this->I18n = I18n::getInstance($this->Config);
        $this->Template->setI18n($this->I18n);

        // IFrameChecker создаём eagerly — он нужен в index.php для HeaderBlock().
        $this->IFrameChecker = new IFrameChecker($this->Config, $this->Logger);
    }

    /**
     * Lazy-initialization для всех Check-компонентов.
     */
    public function __get($name)
    {
        if (isset(self::$lazyMap[$name])) {
            if (!isset($this->lazyComponents[$name])) {
                $factory = self::$lazyMap[$name][1];
                $this->lazyComponents[$name] = $this->$factory();
            }
            return $this->lazyComponents[$name];
        }

        $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1);
        trigger_error("Undefined property via __get(): {$name} in {$trace[0]['file']} on line {$trace[0]['line']}", E_USER_NOTICE);
        return null;
    }

    /**
     * __isset необходим для корректной работы isset($this->Foo) на lazy-свойствах.
     */
    public function __isset($name): bool
    {
        return isset(self::$lazyMap[$name]) || isset($this->lazyComponents[$name]);
    }

    // ---- Фабрики для lazy-компонентов ----

    private function createWhiteListIP() { return new WhiteListIP($this->Config, $this->Logger); }
    private function createBlackListIP() { return new BlackListIP($this->Config, $this->Logger); }
    private function createUserAgentChecker() { return new UserAgentChecker($this->Config, $this->Logger); }
    private function createUserAgentCaptcha() { return new UserAgentChecker($this->Config, $this->Logger, ['listName' => 'captcha_useragent', 'action' => 'CAPTCHA']); }
    private function createUserAgentBlock() { return new UserAgentChecker($this->Config, $this->Logger, ['listName' => 'blacklist_useragent', 'action' => 'BLOCK']); }
    private function createRequestAllow() { return new RequestChecker($this->Config, $this->Logger, ['listName' => 'whitelist_uri', 'action' => 'ALLOW']); }
    private function createRequestBlock() { return new RequestChecker($this->Config, $this->Logger, ['listName' => 'blacklist_uri', 'action' => 'BLOCK']); }
    private function createRequestCaptcha() { return new RequestChecker($this->Config, $this->Logger, ['listName' => 'captcha_uri', 'action' => 'CAPTCHA']); }
    private function createIndexBot() { return new IndexBot($this->Config, $this->Profile, $this->Logger); }
    private function createTorChecker() { return new TorChecker($this->Config, $this->Logger); }
    private function createRefererCaptcha() { return new RefererChecker($this->Config, $this->Logger, ['listName' => 'captcha_referer', 'action' => 'CAPTCHA']); }
    private function createRefererAllow() { return new RefererChecker($this->Config, $this->Logger, ['listName' => 'whitelist_referer', 'action' => 'ALLOW']); }
    private function createRefererBlock() { return new RefererChecker($this->Config, $this->Logger, ['listName' => 'blacklist_referer', 'action' => 'BLOCK']); }
    private function createFingerPrint() { return new FingerPrint($this->Config, $this->Logger); }
    private function createGrayList() { return new GrayList($this->Config, $this->Logger); }
    private function createHTTPChecker() { return new HTTPChecker($this->Config, $this->Logger); }
    private function createMobileChecker() { return new MobileChecker($this->Config, $this->Logger); }
    private function createIFrameChecker() { return new IFrameChecker($this->Config, $this->Logger); }
    private function createASNWhite() { return new ASNChecker($this->Config, $this->Logger, ['listName' => 'whitelist_asn', 'action' => 'ALLOW']); }
    private function createASNBlock() { return new ASNChecker($this->Config, $this->Logger, ['listName' => 'blacklist_asn', 'action' => 'BLOCK']); }
    private function createASNCaptcha() { return new ASNChecker($this->Config, $this->Logger, ['listName' => 'captcha_asn', 'action' => 'CAPTCHA']); }
    private function createFPSChecker() { return new FPSChecker($this->Config, $this->Logger); }

    public function run()
    {
        try {
            if (!$this->isAllowed()) {
                $this->Template->showCaptcha();
            }
        } catch (\Exception $e) {
            $this->Logger->log("System error: " . $e->getMessage());
            $this->Template->showCaptcha();
        }
    }

    private function isAllowed()
    {
        $clientIp = $this->Profile->IP;
        if (PHP_SAPI === 'cli') {
            $this->Logger->log("Script is run from the command line: " . ($_SERVER['PHP_SELF'] ?? ''));
            return true;
        }

        # Проверка куки маркера — РАННИЙ ВОЗВРАТ для счастливого пути.
        # На этом этапе lazy-компоненты ещё не созданы — экономия 2-5 мс.
        if ($this->Marker->isValid()) {
            return true;
        }

        $this->Logger->log("" . $this->Profile->REQUEST_URI);

        if ($this->HTTPChecker->enabled)
            $this->Logger->log("Protocol: " . $this->Profile->HttpVersion);

        if ($this->RefererAllow->enabled || $this->RefererBlock->enabled || $this->RefererCaptcha->enabled)
            $this->Logger->log("REF: " . $this->Profile->Referer);

        $geoipCountry = $_SERVER['GEOIP_COUNTRY_NAME'] ?? 'unknown';
        $this->Logger->log("From: " . $geoipCountry);

        # БОЛЕЕ ТЯЖЕЛЫЕ ПРОВЕРКИ ДОБАВЛЯЮТСЯ В КОНЕЦ
        ##### ALLOW #####

        # Разрешенные IP
        if ($this->WhiteListIP->enabled) {
            if ($this->WhiteListIP->isListed($clientIp)) {
                $this->Logger->log("IP address found in whitelist: $clientIp");
                return true;
            }
        }

        # Разрешенные ASN
        if ($this->ASNWhite->enabled) {
            if ($this->ASNWhite->action == 'ALLOW') {
                if ($this->ASNWhite->Checking($this->Profile->IP)) {
                    $this->Logger->log("ASN allowed");
                    return true;
                }
            }
        }

        # Разрешенные поисковые боты
        if ($this->IndexBot->enabled) {
            if ($this->IndexBot->Checking($clientIp)) {
                $this->Logger->log("Indexing robot");
                return true;
            }
        }

        ##### BLOCK #####

        # Блокировка IPv6
        if ($this->BlackListIP->enabled) {
            if ($this->BlackListIP->ipv6 == 'BLOCK') {
                if ($this->BlackListIP->isIPv6($this->Profile->IP)) {
                    $this->Logger->log("IPv6 blocked");
                    $this->Template->showBlockPage();
                }
            }
        }

        # Блокировка HTTP протоколов
        if ($this->HTTPChecker->enabled) {
            if ($this->HTTPChecker->action == 'BLOCK') {
                if ($this->HTTPChecker->Checking($this->Profile->HttpVersion)) {
                    $this->Logger->log("Version HTTP blocked");
                    if ($this->HTTPChecker->addBlacklistIP) {
                        $this->BlackListIP->add($clientIp, $this->Profile->HttpVersion);
                    }
                    $this->Template->showBlockPage();
                }
            }
        }

        # Блокировка IP
        if ($this->BlackListIP->enabled) {
            if ($this->BlackListIP->isListed($clientIp)) {
                $this->Logger->log("IP address found on blacklist: $clientIp");
                $this->Template->showBlockPage();
            }
        }

        # Блокировка ASN
        if ($this->ASNBlock->enabled) {
            if ($this->ASNBlock->action == 'BLOCK') {
                if ($this->ASNBlock->Checking($this->Profile->IP)) {
                    $this->Logger->log("ASN blocked");
                    $this->Template->showBlockPage();
                }
            }
        }

        # Блокировка TOR
        if ($this->TorChecker->enabled) {
            if ($this->TorChecker->action == 'BLOCK') {
                if ($this->TorChecker->isTor($this->Profile->IP)) {
                    $this->Logger->log("TOR blocked");
                    $this->Template->showBlockPage();
                }
            }
        }

        # Разрешенные URL
        if ($this->RequestAllow->enabled) {
            if ($this->RequestAllow->action == 'ALLOW') {
                if ($this->RequestAllow->isListed($this->Profile->REQUEST_URI)) {
                    $this->Logger->log("REQUEST_URI allowed");
                    return true;
                }
            }
        }

        # Разрешенные User-Agent
        if ($this->UserAgentChecker->enabled) {
            if ($this->UserAgentChecker->isListed($this->Profile->UserAgent)) {
                $this->Logger->log("User-Agent allowed");
                return true;
            }
        }

        # Разрешаенные рефереры
        if ($this->RefererAllow->enabled) {
            if ($this->RefererAllow->isDirect($this->Profile->Referer)) {
                $this->Logger->log("DIRECT allowed");
                $this->Marker->set();
                return true;
            }
        }

        # Проверка User-Agent
        if ($this->UserAgentChecker->enabled) {
            if (!$this->UserAgentChecker->isValid($this->Profile->UserAgent)) {
                $this->Template->showBlockPage();
            }
        }

        # Блокировка User-Agent
        if ($this->UserAgentBlock->enabled) {
            if ($this->UserAgentBlock->Checking($this->Profile->UserAgent)) {
                $this->Logger->log("UserAgent blocked");
                $this->Template->showBlockPage();
            }
        }

        # Блокировка URL
        if ($this->RequestBlock->enabled) {
            if ($this->RequestBlock->action == 'BLOCK') {
                if ($this->RequestBlock->isListed($this->Profile->REQUEST_URI)) {
                    $this->Logger->log("REQUEST_URI blocked");
                    $this->Template->showBlockPage();
                }
            }
        }

        ##### ЗАКРЫВАЮЩИЕ ПРАВИЛА #####

        # Показ капчи для списков
        if ($this->RefererCaptcha->action == 'CAPTCHA') {
            if ($this->RefererCaptcha->Checking($this->Profile->Referer)) {
                $this->Logger->log("HTTP_REFERER captcha");
                return false;
            }
        }
        # Пропускаем посетителей с реферером
        if ($this->RefererAllow->isReferer($this->Profile->Referer)) {
            if ($this->RefererBlock->enabled) {
                if ($this->RefererBlock->Checking($this->Profile->Referer)) {
                    $this->Logger->log("HTTP_REFERER blocked");
                    $this->Template->showBlockPage();
                }
            }
            if ($this->RefererCaptcha->enabled) {
                if ($this->RefererCaptcha->Checking($this->Profile->Referer)) {
                    $this->Logger->log("HTTP_REFERER captcha");
                    return false;
                }
            }
            $this->Logger->log("HTTP_REFERER allowed");
            $this->Marker->set();
            return true;
        }
        # Блокировка посетителей с реферером
        if ($this->RefererBlock->isReferer($this->Profile->Referer)) {
            if ($this->RefererAllow->enabled) {
                if ($this->RefererAllow->Checking($this->Profile->Referer)) {
                    $this->Logger->log("HTTP_REFERER allowed");
                    $this->Marker->set();
                    return true;
                }
            }
            if ($this->RefererCaptcha->enabled) {
                if ($this->RefererCaptcha->Checking($this->Profile->Referer)) {
                    $this->Logger->log("HTTP_REFERER captcha");
                    return false;
                }
            }
            $this->Logger->log("HTTP_REFERER blocked");
            $this->Template->showBlockPage();
        }

        return false;
    }

    public function isAllowed2()
    {
        $Api = Api::getInstance($this);

        // БЕЗОПАСНОСТЬ: SysUpdate больше не запускается из запроса.
        // Обновление — только через CLI (cron/scripts/update.php).

        # Блокировка плохих запросов
        if (!$Api->isPost()) {
            $this->Logger->log("Not a POST request");
            $this->BlackListIP->add($this->Profile->IP, 'Not a POST request');
            $Api->endJSON('block');
        }

        $data = $Api->getData();

        # Блокировка, если не удалось получить fps
        if (!isset($data['frameRate'])) {
            $this->Logger->log("Not frameRate value");
            $Api->endJSON('block');
        }
        $this->Profile->FPS = $data['frameRate'];

        # Блокировка, eсли не удалось получить FingerPrint
        if (!isset($data['fingerPrint']) || empty($data['fingerPrint'])) {
            $this->Logger->log("Not FingerPrint");
            $Api->endJSON('block');
        }
        $this->Profile->FingerPrint = $data['fingerPrint'];

        # Блокировка, если не удалось получить Request_Uri
        if (!isset($data['location']['pathname']) || !isset($data['location']['search'])) {
            $this->Logger->log("Not Request_Uri");
            $Api->endJSON('block');
        }
        $this->Profile->REQUEST_URI = $data['location']['pathname'] . $data['location']['search'];

        # Запрос по событию Закрыл страницу или вкладку
        if ($data['func'] == 'win-close') {
            $this->Logger->log("Closed the verification page");
            $Api->endJSON('');
        }

        # Запрос на установку метки
        if ($data['func'] == 'set-marker' && $Api->isHiddenValue()) {
            $this->Logger->log("Successfully passed the captcha");
            if (session_status() === PHP_SESSION_ACTIVE) {
                @session_regenerate_id(true);
            }
            $this->Marker->set();
            $Api->endJSON('allow');
        }

        # Вывод в лог значения FP
        $this->Logger->log("FP:  " . $this->Profile->FingerPrint);

        if ($this->FPSChecker->enabled)
            $this->Logger->log("FPS: " . $this->Profile->FPS);

        ##### BLOCK #####

        # Блокировка BAS-браузера и старых движков Mozilla
        if (!isset($data['isBas']) || !is_bool($data['isBas'])) {
            $this->Logger->log("Is no parameter isBas or it is not of type bool");
            $Api->endJSON('block');
        }
        if ($data['isBas']) {
            $this->Logger->log("Blocked: BAS browser detected or old driver Mozilla");
            $Api->BlockIP($this->Profile->IP, "BAS browser detected or old driver Mozilla");
            $Api->endJSON('block');
        }

        # Блокировка мобильных девайсов
        if ($this->MobileChecker->enabled) {
            if ($this->MobileChecker->action == 'BLOCK') {
                if ($this->MobileChecker->Checking($this->Profile->isMobile, $data['screenWidth'], $data['pixelRatio'])) {
                    $this->Logger->log("Mobile device blocked");
                    $Api->endJSON('block');
                }
            }
        }

        # Блокировка по FPS
        if ($this->FPSChecker->enabled) {
            if ($this->FPSChecker->action == 'BLOCK') {
                if ($this->FPSChecker->Checking($this->Profile->FPS)) {
                    $this->Logger->log("Blocked: The fps value is below the set value");
                    $Api->endJSON('block');
                }
            }
        }

        # Блокировка по FingerPrint
        if ($this->FingerPrint->enabled) {
            if ($this->FingerPrint->action == 'BLOCK') {
                if ($this->FingerPrint->Checking($this->Profile->FingerPrint)) {
                    $this->Logger->log("FingerPrint blocked");
                    if ($this->FingerPrint->addBlacklistIP) {
                        $this->BlackListIP->add($this->Profile->IP, 'FP ' . $this->Profile->FingerPrint);
                    }
                    $Api->endJSON('block');
                }
            }
        }

        # Блокировка преходов в iframe
        if ($this->IFrameChecker->enabled) {
            if ($this->IFrameChecker->action == 'BLOCK') {
                if ($this->IFrameChecker->Checking($data['mainFrame'])) {
                    $this->Logger->log("IFrame blocked");
                    $Api->endJSON('block');
                }
            }
        }

        /* 
        * CAPTCHA
        **/

        # Проверка IPv6
        if ($this->BlackListIP->enabled) {
            if ($this->BlackListIP->ipv6 == 'CAPTCHA') {
                if ($this->BlackListIP->isIPv6($this->Profile->IP)) {
                    $this->Logger->log("IPv6 captcha");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Показ капчи для User-Agent
        if ($this->UserAgentCaptcha->enabled) {
            if ($this->UserAgentCaptcha->Checking($this->Profile->UserAgent)) {
                $this->Logger->log("Show captcha for UserAgent");
                $Api->endJSON('captcha');
            }
        }

        # Показ капчи для Прямых заходов
        if ($this->RefererCaptcha->enabled) {
            if ($this->RefererCaptcha->isDirect($data['referer'])) {
                $this->Logger->log("Show captcha for DIRECT");
                $Api->endJSON('captcha');
            }
            if ($this->RefererCaptcha->isReferer($data['referer'])) {
                $this->Logger->log("Show captcha for REFERRER");
                $Api->endJSON('captcha');
            }
            if ($this->RefererCaptcha->action == 'CAPTCHA') {
                if ($this->RefererCaptcha->Checking($data['referer'])) {
                    $this->Logger->log("Show captcha to list REFERRER");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Проверка для мобильных девайсов
        if ($this->MobileChecker->enabled) {
            if ($this->MobileChecker->action == 'CAPTCHA') {
                if ($this->MobileChecker->Checking($this->Profile->isMobile, $data['screenWidth'], $data['pixelRatio'])) {
                    $this->Logger->log("Show captcha for Mobile device");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Капча по FPS
        if ($this->FPSChecker->enabled) {
            if ($this->FPSChecker->action == 'CAPTCHA') {
                if ($this->FPSChecker->Checking($this->Profile->FPS)) {
                    $this->Logger->log("Captcha: The fps value is below the set value");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Проверка для iframe
        if ($this->IFrameChecker->enabled) {
            if ($this->IFrameChecker->action == 'CAPTCHA') {
                if ($this->IFrameChecker->Checking($data['mainFrame'])) {
                    $this->Logger->log("IFrame captcha");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Показ капчи для Протоколов
        if ($this->HTTPChecker->enabled) {
            if ($this->HTTPChecker->action == 'CAPTCHA') {
                if ($this->HTTPChecker->Checking($this->Profile->HttpVersion)) {
                    $this->Logger->log("Show captcha for protocol: " . $this->Profile->HttpVersion);
                    $Api->endJSON('captcha');
                }
            }
        }

        # Проверка ASN
        if ($this->ASNCaptcha->enabled) {
            if ($this->ASNCaptcha->action == 'CAPTCHA') {
                if ($this->ASNCaptcha->Checking($this->Profile->IP)) {
                    $this->Logger->log("Show captcha for ASN");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Блокировка URL
        if ($this->RequestCaptcha->enabled) {
            if ($this->RequestCaptcha->action == 'CAPTCHA') {
                if ($this->RequestCaptcha->isListed($this->Profile->REQUEST_URI)) {
                    $this->Logger->log("Show captcha for REQUEST_URI");
                    $Api->endJSON('captcha');
                }
            }
        }

        # Тор IP
        if ($this->TorChecker->enabled) {
            if ($this->TorChecker->action == 'CAPTCHA') {
                if ($this->TorChecker->isTor($this->Profile->IP)) {
                    $this->Logger->log("IP is TOR captcha");
                    $Api->endJSON('captcha');
                }
            }
        }

        $this->Logger->log("Passed all filters");
        $this->Marker->set();

        $Api->endJSON('allow');
    }
}
