<?php

namespace WAFSystem;

/**
 * Маркер прохождения проверки (cookie).
 *
 * БЕЗОПАСНОСТЬ:
 * - Имя куки — RayIDSecret (HMAC от IP+UA, 32 hex), не предсказуемо без секрета.
 * - Значение куки — HMAC-подписанный nonce+expires, проверяется сервером
 *   (Profile::verifyMarkerValue). Ранее isValid() проверял только наличие куки.
 * - Cookie-флаги: HttpOnly=true, SameSite=Lax, Secure=по факту HTTPS.
 */
class Marker
{
    private $Config;
    private $profile;
    private $logger;
    private $expireDays;
    private $headerProxy;

    public function __construct(Config $config, Profile $profile, Logger $logger)
    {
        $this->Config = $config;
        $this->profile = $profile;
        $this->logger = $logger;

        $config->init('cookie', 'expire_days', 30, 'дней действия метки');

        $this->expireDays = (int)$config->get('cookie', 'expire_days', 30);

        // HeaderProxy нужен, чтобы корректно определять HTTPS за прокси.
        $this->headerProxy = new HeaderProxy($config);
    }

    public function set($time = null)
    {
        if ($time === null) {
            $time = time() + $this->expireDays * 86400;
        }

        $cookieValue = $this->profile->computeMarkerValue($time);

        setcookie(
            $this->profile->RayIDSecret,
            $cookieValue,
            [
                'expires'  => $time,
                'path'     => '/',
                'httponly' => true,
                'secure'   => $this->headerProxy->isHttps(),
                'samesite' => 'Lax',
            ]
        );

        // Дублируем в $_COOKIE, чтобы isValid() сработал в текущем запросе.
        $_COOKIE[$this->profile->RayIDSecret] = $cookieValue;

        $this->logger->logMessage("Tag set");
    }

    public function remove()
    {
        $this->set(time() - 3600);
    }

    /**
     * Проверяет, прошёл ли посетитель проверку ранее.
     *
     * Возвращает true ТОЛЬКО если:
     * - кука с именем RayIDSecret существует,
     * - её значение корректно подписано HMAC-секретом сервера,
     * - и срок действия не истёк.
     */
    public function isValid(): bool
    {
        $cookieName = $this->profile->RayIDSecret;
        if (!isset($_COOKIE[$cookieName])) {
            return false;
        }
        $value = $_COOKIE[$cookieName];
        if (!is_string($value) || $value === '') {
            return false;
        }
        return $this->profile->verifyMarkerValue($value);
    }
}
