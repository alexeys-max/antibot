<?php

namespace WAFSystem;

/**
 * Обновление системы из репозитория.
 *
 * БЕЗОПАСНОСТЬ:
 * - Класс НЕ запускается автоматически из xhr.php. Триггер только через CLI
 *   (cron/scripts/update.php) или через административный API с auth_key.
 * - При распаковке ZIP каждый путь валидируется на path traversal (ZIP Slip).
 * - branch валидируется regex'ом [a-zA-Z0-9._-]+.
 * - Перед удалением старых файлов проверяем, что newPath лежит внутри baseDir.
 */
class SysUpdate
{
    private $repoOwner = 'githubniko';
    private $repoName = 'antibot';
    private $branch = 'main';
    private $enabled = false;
    private $lastUpdate = null;
    private $lastCommitDate = null;

    private $Config;
    private $Logger;

    public function __construct(Config $config, Logger $logger)
    {
        $this->Config = $config;
        $this->Logger = $logger;

        $this->enabled = $this->Config->init('sysupdate', 'enabled', 'Off', 'On - обновит систему при следующем запуске (только CLI/admin)');
        $this->branch = $this->Config->init('sysupdate', 'branch', 'master', 'master - стабильный выпуск, dev - для тестировщиков');
        $this->lastUpdate = $this->Config->init('sysupdate', 'lastupdate', '', 'дата последнего обновления системы');
    }

    /**
     * Запускает проверку и обновление. Должен вызываться ИЗ CLI/admin-контекста,
     * НЕ из обычного запроса xhr.php.
     *
     * @param bool $force проверить даже если enabled=false (для CLI)
     */
    public function run(bool $force = false): void
    {
        if (!$this->enabled && !$force) {
            return;
        }

        // Валидация branch — защита от SSRF через модификацию config.ini.
        if (!preg_match('/^[a-zA-Z0-9._-]+$/', $this->branch)) {
            $this->Logger->log("Invalid branch name rejected: " . $this->branch, [static::class]);
            return;
        }

        $lock = new Lock($this->Config->BasePath . '.sysupgrade.lock');
        $lock->Lock();
        $this->Logger->log("Start upgrade", [static::class]);
        try {
            if ($this->isUpdate()) {
                $this->Logger->log("Found new version", [static::class]);
                if ($this->Update()) {
                    $this->Logger->log("Updated successfully", [static::class]);
                    $this->Config->set('sysupdate', 'lastupdate', date('Y-m-d H:i:s'));
                } else {
                    $this->Logger->log("Update error, please try again", [static::class]);
                }
            }
            $this->Config->set('sysupdate', 'enabled', 'Off');
            $versionFile = $this->Config->BasePath . 'VERSION';
            if (is_file($versionFile)) {
                $this->Config->set('sysupdate', 'version', trim(file_get_contents($versionFile)));
            }
        } finally {
            $this->Logger->log("End upgrade", [static::class]);
            $lock->Unlock();
        }
    }

    private function GetLastDateUpdate()
    {
        $apiUrl = "https://api.github.com/repos/{$this->repoOwner}/{$this->repoName}/commits/{$this->branch}";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'AntibotWAF_System');
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        if (!$response) {
            $this->Logger->log("Failed to fetch GitHub API response.", [static::class]);
            return null;
        }

        $commitData = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE || !isset($commitData['commit']['committer']['date'])) {
            $this->Logger->log("Invalid GitHub API response.", [static::class]);
            return null;
        }

        return strtotime($commitData['commit']['committer']['date']);
    }

    private function isUpdate()
    {
        $this->lastCommitDate = $this->GetLastDateUpdate();
        if ($this->lastCommitDate === null) {
            return false;
        }
        if (!empty($this->lastUpdate) && $this->lastCommitDate <= strtotime($this->lastUpdate)) {
            return false;
        }
        return true;
    }

    public function Update()
    {
        $baseDir = rtrim($this->Config->BasePath, "/\\");
        $zipUrl = "https://github.com/{$this->repoOwner}/{$this->repoName}/archive/refs/heads/{$this->branch}.zip";
        $zipFile = $baseDir . "/{$this->repoName}-{$this->branch}.zip";

        $curl = new \Utility\Curl(30);
        $zipContent = $curl->fetch($zipUrl);

        if ($zipContent === false) {
            $this->Logger->log("Failed to download archive from GitHub.", [static::class]);
            return false;
        }

        if (file_put_contents($zipFile, $zipContent) === false) {
            $this->Logger->log("Failed to save archive.", [static::class]);
            return false;
        }

        if (!class_exists('ZipArchive')) {
            $this->Logger->log("ZipArchive extension required.", [static::class]);
            return false;
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipFile) !== true) {
            $this->Logger->log("Failed to open archive.", [static::class]);
            return false;
        }

        // Сначала извлекаем во временную директорию, проверяем, и только потом
        // переносим на место — отказоустойчивость при частичной распаковке.
        $tmpExtract = $baseDir . '/.upgrade_tmp_' . bin2hex(random_bytes(8));
        if (!mkdir($tmpExtract, 0755, true)) {
            $this->Logger->log("Failed to create temp extraction dir.", [static::class]);
            $zip->close();
            return false;
        }

        try {
            // Извлекаем все файлы, проверяя пути на path traversal (ZIP Slip).
            $extractedFiles = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = $zip->getNameIndex($i);
                if ($filename === false) continue;

                // Нормализуем путь: убираем корневую папку {repoName}-{branch}/
                $relative = str_replace("{$this->repoName}-{$this->branch}/", '', $filename);
                // Если после замены остались абсолютные пути или ../ — пропускаем.
                if (preg_match('#(^|/)\.\.(/|$)#', $relative) || strpos($relative, '/') === 0) {
                    $this->Logger->log("Skipping suspicious zip entry: {$filename}", [static::class]);
                    continue;
                }

                $targetPath = $tmpExtract . '/' . $relative;

                // Двойная проверка: realpath должен быть внутри tmpExtract.
                $targetDir = realpath(dirname($targetPath));
                $tmpReal = realpath($tmpExtract);
                if ($targetDir === false || $tmpReal === false ||
                    strpos($targetDir . DIRECTORY_SEPARATOR, $tmpReal . DIRECTORY_SEPARATOR) !== 0) {
                    $this->Logger->log("Skipping out-of-sandbox zip entry: {$filename}", [static::class]);
                    continue;
                }

                if (substr($filename, -1) === '/') {
                    if (!is_dir($targetPath)) {
                        mkdir($targetPath, 0755, true);
                    }
                } else {
                    $stream = $zip->getStream($filename);
                    if ($stream !== false) {
                        file_put_contents($targetPath, $stream);
                        fclose($stream);
                        $extractedFiles[] = $relative;
                    }
                }
            }
        } finally {
            $zip->close();
        }

        // Удаляем старую версию (исключения сохраняем).
        $exclude = [
            '.', '..',
            '.git', '.gitignore',
            'lists', 'logs', 'cache',
            $this->Config->configFileName,
            'lang', // языковые пакеты не затираем при обновлении
            basename($zipFile),
            basename($tmpExtract),
        ];
        $this->removeDirectory($baseDir, $exclude);

        // Переносим новые файлы.
        foreach ($extractedFiles as $relative) {
            $src = $tmpExtract . '/' . $relative;
            $dst = $baseDir . '/' . $relative;
            if (!is_dir(dirname($dst))) {
                mkdir(dirname($dst), 0755, true);
            }
            rename($src, $dst);
        }

        $this->removeDirectory($tmpExtract, []);
        unlink($zipFile);

        return true;
    }

    private function removeDirectory($dir, $exclude = [])
    {
        if (!is_dir($dir)) return;

        $files = array_diff(scandir($dir), $exclude);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->removeDirectory($path, $exclude);
            } else {
                @unlink($path);
            }
        }

        $baseReal = realpath($this->Config->BasePath);
        if (realpath($dir) != $baseReal) {
            @rmdir($dir);
        }
    }
}
