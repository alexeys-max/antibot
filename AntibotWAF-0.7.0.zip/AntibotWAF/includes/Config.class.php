<?php

namespace WAFSystem;

class Config
{
    private $Lock;

    private static $instances = [];
    private $config = [];
    private $comments = [];
    public $BasePath;
    public $CachePath; // папка для хранения временные файлов
    public $DOCUMENT_ROOT;
    public $ANTIBOT_PATH;
    public $HTTP_HOST;
    public $HTTPS;
    public $configFileName = 'config.ini';
    private $configFile;
    private $useBooleanAsOnOff = true;

    private function __construct($documentRoot, $antibotPath)
    {
        $this->DOCUMENT_ROOT = $documentRoot;
        $this->ANTIBOT_PATH = $antibotPath;
        $this->HTTP_HOST = getenv("HTTP_HOST");
        if (isset($_SERVER['HTTPS'])) {
            $this->HTTPS =  $_SERVER['HTTPS'] === 'on' ? true : false;
        } else {
            $this->HTTPS = isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https' ? true : null;
        }


        $this->BasePath = rtrim($documentRoot, "/\\") . '/' . ltrim($antibotPath, "/\\");
        $this->CachePath = $this->BasePath . 'cache/';
        $this->configFile = $this->BasePath . $this->configFileName;
        $this->Lock = new Lock($this->CachePath . 'lock/.' . pathinfo($this->configFileName, PATHINFO_FILENAME) .'.lock');

        if(!is_dir($this->CachePath)) {
            mkdir($this->CachePath, 0755, true);
        }

        $this->loadConfig();
    }

    /**
     * БЕЗОПАСНОСТЬ: приводит путь (относительный к BasePath) к абсолютному
     * и проверяет, что результат остаётся внутри BasePath. Защищает от
     * path traversal через config.ini (например log_file = "../../shell.php").
     *
     * @param string $relativePath путь относительно BasePath
     * @return string абсолютный путь внутри BasePath
     * @throws \RuntimeException если путь выходит за пределы BasePath
     */
    public function resolveSafePath(string $relativePath): string
    {
        $relativePath = ltrim($relativePath, "/\\");
        $absolute = $this->BasePath . $relativePath;

        // realpath() разрешает ../, символические ссылки и т.д.
        // Если файла ещё нет — используем realpath() родительской директории.
        $resolvedParent = realpath(dirname($absolute));
        if ($resolvedParent === false) {
            // Пытаемся создать родительскую директорию.
            @mkdir(dirname($absolute), 0755, true);
            $resolvedParent = realpath(dirname($absolute));
            if ($resolvedParent === false) {
                throw new \RuntimeException("Cannot resolve parent directory for path: " . $absolute);
            }
        }

        $baseReal = realpath($this->BasePath);
        if ($baseReal === false) {
            $baseReal = $this->BasePath;
        }
        $baseReal = rtrim($baseReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

        // Проверяем, что resolvedParent начинается с BasePath.
        if (strpos($resolvedParent . DIRECTORY_SEPARATOR, $baseReal) !== 0) {
            throw new \RuntimeException("Path traversal attempt blocked: " . $relativePath);
        }

        return $resolvedParent . DIRECTORY_SEPARATOR . basename($absolute);
    }

    public static function getInstance($documentRoot = null, $antibotPath = null)
    {
        if ($documentRoot === null) {
            // CLI/cron fallback: getenv() возвращает пустую строку в CLI,
            // поэтому проверяем $_SERVER['DOCUMENT_ROOT'] (он выставляется
            // cron-скриптами и smoke-тестом явно).
            $docRoot = getenv("DOCUMENT_ROOT");
            if ($docRoot === false || $docRoot === '') {
                $docRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
            }
            $documentRoot = rtrim($docRoot, "/\\");
        }

        if ($antibotPath === null) {
            // БЕЗОПАСНОСТЬ: позволяем переопределить имя папки через env var
            // (ANTIBOT_PATH). Это даёт "security through obscurity" — атакующий
            // не может угадать имя папки. Дефолт — /AntibotWAF/ (как в оригинале).
            //
            // Пример настройки в nginx:
            //   fastcgi_param ANTIBOT_PATH /sys-prot-7f3a/;
            $envPath = $_SERVER['ANTIBOT_PATH'] ?? getenv('ANTIBOT_PATH');
            $antibotPath = ($envPath !== false && $envPath !== null && $envPath !== '')
                ? '/' . trim($envPath, "/\\") . '/'
                : '/AntibotWAF/';
        }

        $key = md5($documentRoot . $antibotPath);

        if (!isset(self::$instances[$key])) {
            self::$instances[$key] = new self($documentRoot, $antibotPath);
        }

        return self::$instances[$key];
    }

    public function setBooleanFormat($useOnOff)
    {
        $this->useBooleanAsOnOff = (bool)$useOnOff;
    }

    private function sanitizeKey($key)
    {
        $key = preg_replace('/[^a-zA-Z0-9_\-]/', '', $key);

        if (preg_match('/^[0-9]/', $key)) {
            $key = 'key_' . $key;
        }

        if (empty($key)) {
            $key = 'key_' . uniqid();
        }

        return $key;
    }

    private function loadConfig()
    {
        $iniFile = $this->configFile;
        if (!file_exists($iniFile)) {
            $this->config = [];
            $this->comments = [];
            return;
        }

        // ПРОИЗВОДИТЕЛЬНОСТЬ: APCu-кеш для распарсенного конфига.
        // Ключ — filemtime(ini-файла). Если файл не менялся, берём из APCu —
        // это убирает чтение+парсинг INI на каждом запросе (~2 мс → ~0.05 мс).
        $cacheKey = 'antibot_config_' . md5($iniFile);
        $mtime = filemtime($iniFile);
        $apcuKey = $cacheKey . '_' . $mtime;

        if (function_exists('apcu_enabled') && apcu_enabled()) {
            $cached = apcu_fetch($apcuKey);
            if (is_array($cached) && isset($cached['config']) && isset($cached['comments'])) {
                $this->config = $cached['config'];
                $this->comments = $cached['comments'];
                return;
            }
        }

        $lines = file($iniFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $currentSection = '';
        $this->config = [];
        $this->comments = [];

        foreach ($lines as $line) {
            $line = trim($line);

            if (preg_match('/^\[([^]]+)\]$/', $line, $matches)) {
                $currentSection = $this->sanitizeKey($matches[1]);
                $this->comments[$currentSection]['__section_comment__'] = '';
                continue;
            }

            if (strpos($line, ';') === 0) {
                if ($currentSection === '') {
                    $this->comments['__global_comments__'][] = $line;
                } else {
                    $this->comments[$currentSection]['__section_comment__'] .= $line . "\n";
                }
                continue;
            }

            if (strpos($line, '=') !== false) {
                list($key, $value) = array_map('trim', explode('=', $line, 2));
                $key = $this->sanitizeKey($key);

                $paramComment = '';
                if (($commentPos = strpos($value, ';')) !== false) {
                    $paramComment = substr($value, $commentPos);
                    $value = trim(substr($value, 0, $commentPos));
                }

                $value = $this->parseValue($value);

                $this->config[$currentSection][$key] = $value;
                if ($paramComment !== '') {
                    $this->comments[$currentSection][$key] = $paramComment;
                }
            }
        }

        // Сохраняем в APCu на 60 секунд (реальный инвалидатор — filemtime в ключе).
        if (function_exists('apcu_enabled') && apcu_enabled()) {
            apcu_store($apcuKey, ['config' => $this->config, 'comments' => $this->comments], 60);
        }
    }

    private function parseValue($value)
    {
        if (preg_match('/^["\'](.*)["\']$/', $value, $matches)) {
            # для массивов
            if(preg_match('/\,/', $matches[1])) {
                $str = str_replace(' ', '', $matches[1]);
                return explode(',', $str);
            }

            return $matches[1];
        }

        $lowerValue = strtolower($value);
        $booleanMap = [
            'true' => true,
            'on' => true,
            'yes' => true,
            '1' => true,
            'false' => false,
            'off' => false,
            'no' => false,
            '0' => false
        ];

        if (isset($booleanMap[$lowerValue])) {
            return $booleanMap[$lowerValue];
        }

        if (is_numeric($value)) {
            return strpos($value, '.') !== false ? (float)$value : (int)$value;
        }

        return $value;
    }

    public function get($section, $key, $default = null)
    {
        $section = $this->sanitizeKey($section);
        $key = $this->sanitizeKey($key);

        if (isset($this->config[$section][$key])) {
            return $this->config[$section][$key];
        }

        return $default;
    }
    /**
     * Изменяет или устанавливает параметр
     */
    public function set($section, $key, $value, $comment = null)
    {
        $section = $this->sanitizeKey($section);
        $key = $this->sanitizeKey($key);

        if (!isset($this->config[$section])) {
            $this->config[$section] = [];
            $this->comments[$section]['__section_comment__'] = '';
        }

        $this->config[$section][$key] = $value;

        if ($comment !== null) {
            $this->comments[$section][$key] = '; ' . ltrim($comment, '; ');
        }

        $this->saveConfig();

        return $value;
    }
    /**
     * Если параметр не существует, то создает его. Возвращает значение созданного или текущего значения
     */
    public function init($section, $key, $value, $comment = null)
    {
        $getValue = $this->get($section, $key);
        if (is_null($getValue)) {
            return $this->set($section, $key, $value, $comment);
        }
        return $getValue;
    }

    private function formatValue($value)
    {
        if (is_bool($value)) {
            return $this->useBooleanAsOnOff
                ? ($value ? 'On' : 'Off')
                : ($value ? 'true' : 'false');
        }

        if (is_array($value)) {
            return '"' . implode(',', array_map('addslashes', $value)) . '"';
        }

        if (is_int($value) || is_float($value)) {
            return $value;
        }

        if (preg_match('/^[a-zA-Z0-9_\-\.]+$/', $value) && !is_numeric($value)) {
            return $value;
        }

        return '"' . addslashes($value) . '"';
    }

    private function saveConfig()
    {
        $content = '';

        if (!empty($this->comments['__global_comments__'])) {
            $content .= implode("\n", $this->comments['__global_comments__']) . "\n\n";
        }

        foreach ($this->config as $section => $params) {
            if (!empty($this->comments[$section]['__section_comment__'])) {
                $content .= trim($this->comments[$section]['__section_comment__']) . "\n";
            }

            $content .= "[$section]\n";

            foreach ($params as $key => $value) {
                $line = "$key = " . $this->formatValue($value);

                if (!empty($this->comments[$section][$key])) {
                    $line .= ' ' . $this->comments[$section][$key];
                }

                $content .= $line . "\n";
            }

            $content .= "\n";
        }

        $this->Lock->Lock();
        try {
            $tempFile = tempnam(dirname($this->configFile), 'tmp_');
            // БЕЗОПАСНОСТЬ: tempnam по умолчанию создаёт файл 0600 на POSIX,
            // но на shared-хостинге и Windows права могут отличаться. Ставим явно.
            chmod($tempFile, 0600);

            if (file_put_contents($tempFile, $content) === false) {
                @unlink($tempFile);
                throw new \RuntimeException("Failed to write temp config file");
            }

            if (!rename($tempFile, $this->configFile)) {
                @unlink($tempFile);
                throw new \RuntimeException("Failed to replace config file");
            }

            chmod($this->configFile, 0640);
        } finally {
            $this->Lock->Unlock();
        }
    }

    public function getAll()
    {
        $this->loadConfig();
        return $this->config;
    }

    public function getAllWithComments()
    {
        $this->loadConfig();
        return [
            'config' => $this->config,
            'comments' => $this->comments
        ];
    }
    public function reloadConfig()
    {
        $this->loadConfig();
    }
}
