<?php

namespace WAFSystem;

/**
 * Класс содержит базовые методы работы с листами
 */
abstract class ListBase
{
    protected $absolutePath;
    protected $path; // путь от корня проекта
    protected $listName; // название листа в конфиг-файле
    protected $Config;
    protected $Logger;
    protected $Lock;
    public $enabled = true;

    public function __construct($pathFile, Config $config, Logger $logger)
    {
        $this->Config = $config;
        $this->Logger = $logger;
        $this->Lock = new Lock($this->Config->CachePath . 'lock/.' . $this->listName . '.lock');

        // БЕЗОПАСНОСТЬ: валидируем путь к файлу листа на path traversal.
        // Если в config.ini прописан путь вида "../../shell.php", это не должно
        // привести к записи за пределами BasePath.
        try {
            $this->absolutePath = $config->resolveSafePath($pathFile);
        } catch (\RuntimeException $e) {
            $this->Logger->log("Blocked unsafe list path: " . $pathFile, [static::class]);
            $this->absolutePath = $config->BasePath . ltrim($pathFile, "/\\");
            $this->enabled = false;
        }
        $this->path = $pathFile;

        if (!$this->enabled) return; // выходим, если модуль выключен

        // ПРОИЗВОДИТЕЛЬНОСТЬ: убрали waitForUnlock() из конструктора.
        // Он делал 4 syscall (file_exists+filemtime+file_get_contents+posix_kill)
        // на КАЖДОМ конструкторе ListBase, на КАЖДОМ запросе. flock в Lock::Lock()
        // уже обрабатывает конкуренцию атомарно — polling не нужен.
        $this->initListFile();
    }

    /**
     * Проверяет наличие значения в листе
     */
    public function isListed($value)
    {
        if (!$this->validate($value)) {
            $this->Logger->log("Error: The value '$value' failed validation", [static::class]);
            return false;
        }

        return $this->checkInList($value);
    }

    /**
     * Добавляет в конец списка
     */
    public function add($value, $comment = '')
    {
        $this->Lock->Lock();
        try {
            if (!$this->validate($value)) {
                $this->Logger->log("Error: The value '$value' failed validation", [static::class]);
                return;
            }


            if ($this->isListed($value)) {
                return;
            }

            $entry = $this->formatEntry($value, $comment);
            $this->saveEntry($entry);

            // ПРОИЗВОДИТЕЛЬНОСТЬ: инвалидируем APCu-кеш листа после записи.
            $this->invalidateListCache();

            $this->Logger->logMessage("Value added to list: " . $value . " (" . $this->path . ")");
        } finally {
            $this->Lock->Unlock();
        }
    }

    /**
     * Читает список в массив
     */
    public function readToArray()
    {
        $arr = [];
        $file = fopen($this->absolutePath, 'r');
        if (!$file) {
            $this->Logger->logMessage("Error reading file: " . $this->absolutePath, [static::class]);
            return false;
        }

        try {
            while (($line = fgets($file)) !== false) {
                $lineValue = $this->extractFromLine($line);
                if (!empty($lineValue)) {
                    array_push($arr, $lineValue);
                }
            }
        } finally {
            fclose($file);
        }
        return $arr;
    }

    /**
     * Метод задает шаблон заполнения листа
     */
    protected function formatEntry($value, $comment)
    {
        return $value . (empty($comment) ? '' : " # " . date("Y-m-d H:i:s") . ' ' . trim($comment));
    }

    /**
     * Проверяет наличие записи в листе.
     *
     * ПРОИЗВОДИТЕЛЬНОСТЬ: использует APCu-кеш распарсенных значений.
     * Ключ — md5(абсолютный путь) + filemtime. На больших листах
     * (1000+ строк) это даёт 100-200× ускорение (с 20 мс до 0.1 мс).
     */
    protected function checkInList($value)
    {
        if (!is_file($this->absolutePath)) {
            $this->Logger->log("Critical error: file list not found, check parameters " . $this->listName, [static::class]);
            return false;
        }

        $entries = $this->getEntries();

        foreach ($entries as $lineValue) {
            if ($this->Comparison($lineValue, $value)) {
                $this->Logger->log("Value found in list: " . $lineValue . " (" . $this->path . ")", [static::class]);
                return true;
            }
        }

        return false;
    }

    /**
     * Загружает все валидные записи листа с APCu-кешем.
     *
     * @return string[] список валидных значений (без комментариев)
     */
    protected function getEntries(): array
    {
        $mtime = @filemtime($this->absolutePath);
        if ($mtime === false) {
            return [];
        }

        $cacheKey = 'antibot_list_' . md5($this->absolutePath) . '_' . $mtime;

        if (function_exists('apcu_enabled') && apcu_enabled()) {
            $cached = apcu_fetch($cacheKey);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $entries = [];
        $file = fopen($this->absolutePath, 'r');
        if (!$file) {
            $this->Logger->logMessage("Error reading file: " . $this->absolutePath, [static::class]);
            return [];
        }

        try {
            while (($line = fgets($file)) !== false) {
                $lineValue = $this->extractFromLine($line);
                if (!empty($lineValue) && $this->validate($lineValue)) {
                    $entries[] = $lineValue;
                }
            }
        } finally {
            fclose($file);
        }

        if (function_exists('apcu_enabled') && apcu_enabled()) {
            apcu_store($cacheKey, $entries, 60);
        }

        return $entries;
    }

    /**
     * Обрабатывает сравнение значений. Нужно переопределить для сравнения IP или других нетиповых значений
     */
    protected function Comparison($value1, $value2)
    {
        if ($value1 === $value2)
            return true;
        return false;
    }
    /**
     * Инициализация, вызывается в конструкторе класса
     */
    protected function initListFile()
    {
        $this->Lock->Lock();
        try {
            if (!file_exists($this->absolutePath)) {
                $this->saveListFile();
                $this->Logger->logMessage("New list file created: " . $this->absolutePath);

                $this->eventInitListFile();
            }
        } finally {
            $this->Lock->Unlock();
        }
    }

    /**
     * Очищает APCu-кеш распарсенных записей этого листа.
     * Вызывается после любой модификации файла (add, eventInitListFile и т.д.).
     */
    protected function invalidateListCache(): void
    {
        if (!function_exists('apcu_enabled') || !apcu_enabled()) {
            return;
        }
        // APCu не умеет удалять по префиксу, поэтому чистим по известному паттерну.
        // Простой подход: перебираем ключи с известным префиксом.
        $pattern = '/^antibot_list_' . preg_quote(md5($this->absolutePath), '/') . '_/';
        $iter = new \APCUIterator($pattern, APC_ITER_KEY, 100);
        foreach ($iter as $entry) {
            apcu_delete($entry['key']);
        }
    }

    /**
     * Записывает данные в лист
     */
    protected function saveListFile()
    {
        $defaultContent = $this->createDefaultFileContent();
        file_put_contents($this->absolutePath, $defaultContent);
    }

    /**
     * Метод записи в конец листа
     */
    protected function saveEntry($value) {
    $file = fopen($this->absolutePath, 'a+'); // Открываем для чтения и записи
    if (flock($file, LOCK_EX)) {
        // Проверяем последний символ файла
        fseek($file, -1, SEEK_END);
        $fileSize = ftell($file);
        
        if ($fileSize > 0) { // Если файл не пустой
            $lastChar = fread($file, 1);
            if ($lastChar != "\n") {
                fwrite($file, PHP_EOL); // Добавляем перенос, если его нет
            }
        }
        
        fwrite($file, $value); // Пишем саму запись
        flock($file, LOCK_UN);
    }
    fclose($file);
}

    /**
     * Извлекает значение из строки. Удаляет комментарии 
     */
    protected function extractFromLine($line)
    {
        $line = trim(preg_replace('/#.*$/', '', $line));
        return $line;
    }

    protected function eventInitListFile() {} // Событие срабатывает после создании файла листа. Нужно, если требуется сделать первую запись в лист сразу после создания, например внести белые ip-адреса серверов
    protected function validate($value)
    {
        return true;
    } // Проверяет извеченное из листа значение

    abstract protected function createDefaultFileContent(); // Метод для первоначального заполнения листа, например примерами/шаблонами

}
