<?php

namespace Utility;

/**
 * HTTP-клиент для внешних запросов (списки Tor, ASN, обновление системы).
 *
 * БЕЗОПАСНОСТЬ:
 * - URL-схема ограничена https (и http только через явный флаг) —
 *   защищает от SSRF через file://, gopher://, ldap:// и т.д.
 * - Убран exec() fallback в fileExistsBeyondOpenBasedir() —
 *   оставлен только is_readable().
 */
class Curl
{
    private $timeout;
    private $verifySsl;
    private $curlOptions;
    private $allowInsecureScheme = false;

    public function __construct($timeout = 10, $verifySsl = true)
    {
        $this->timeout = (int)$timeout;
        $this->verifySsl = (bool)$verifySsl;

        $this->curlOptions = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => $this->verifySsl,
            CURLOPT_SSL_VERIFYHOST => $this->verifySsl ? 2 : 0,
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => 'AntibotWAF/2.0',
            CURLOPT_FAILONERROR => true,
        ];

        # CA-сертификат для CGI/cli режима (под apache2handler обычно доступен системный).
        if (PHP_SAPI != 'apache2handler') {
            $caPaths = [
                '/etc/ssl/certs/ca-certificates.crt',    // Ubuntu/Debian
                '/etc/pki/tls/certs/ca-bundle.crt',      // RHEL/CentOS
                '/usr/local/etc/openssl/cert.pem',       // macOS (Homebrew)
            ];

            foreach ($caPaths as $path) {
                if (is_readable($path)) {
                    $this->curlOptions[CURLOPT_CAINFO] = $path;
                    break;
                }
            }
        }
    }

    /**
     * Разрешает http:// схему (по умолчанию только https).
     */
    public function setAllowInsecureScheme(bool $allow): void
    {
        $this->allowInsecureScheme = $allow;
    }

    /**
     * Выполняет HTTP-запрос.
     *
     * @param string $url URL для запроса
     * @param array $headers Дополнительные заголовки
     * @return string Тело ответа
     * @throws \RuntimeException При ошибках запроса
     */
    public function fetch($url, $headers = [])
    {
        $len = 51;
        $urlShort = strlen($url) <= $len ? substr($url, 0, $len) . '...' : $url;

        // БЕЗОПАСНОСТЬ: валидация URL и схемы.
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new \InvalidArgumentException("Invalid URL provided " . $urlShort);
        }
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if ($scheme === 'https') {
            // OK
        } elseif ($scheme === 'http' && $this->allowInsecureScheme) {
            // OK (явно разрешено)
        } else {
            throw new \InvalidArgumentException("Disallowed URL scheme '{$scheme}' for " . $urlShort);
        }

        $ch = curl_init();
        $verboseStream = fopen('php://temp', 'w+');
        curl_setopt($ch, CURLOPT_VERBOSE, true);
        curl_setopt($ch, CURLOPT_STDERR, $verboseStream);

        try {
            $options = $this->curlOptions + [
                CURLOPT_URL => $url,
                CURLOPT_HTTPHEADER => $headers,
            ];

            curl_setopt_array($ch, $options);

            $response = curl_exec($ch);

            if ($response === false) {
                rewind($verboseStream);
                $debug = stream_get_contents($verboseStream);

                $error = curl_error($ch);
                $errno = curl_errno($ch);
                throw new \RuntimeException(
                    sprintf("curl %s: [%d] %s\n" . $debug, $urlShort, $errno, $error),
                    $errno
                );
            }

            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode >= 400) {
                rewind($verboseStream);
                $debug = stream_get_contents($verboseStream);
                throw new \RuntimeException(
                    sprintf("curl %s HTTP error %d\n" . $debug, $urlShort, $httpCode),
                    $httpCode
                );
            }

            return $response;
        } finally {
            if (is_resource($ch)) {
                curl_close($ch);
            }
        }
    }
}
