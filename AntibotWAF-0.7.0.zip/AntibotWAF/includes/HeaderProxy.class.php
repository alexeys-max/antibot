<?php

namespace WAFSystem;

/**
 * Класс предназначен для получения информации с дополнительных
 * заголовков прокси-серверов и балансировщиков.
 *
 * ВАЖНО: заголовки X-Forwarded-For / X-Real-IP доверяются ТОЛЬКО если
 * запрос пришёл от доверенного прокси (trusted_proxies в config.ini).
 * Иначе атакующий может подделать заголовок и обойти IP-фильтры.
 */
class HeaderProxy
{
    public $enabled = false;

    private $Config;
    private $header_ip = 'X-Real-IP';
    private $header_http_version = 'X-Forwarded-Http-Version';
    private $header_proto = 'X-Forwarded-Proto';

    /** @var string[]|null Список доверенных прокси (IP/CIDR) или null если проверка отключена */
    private $trustedProxies = null;

    public function __construct(Config $config)
    {
        $this->Config = $config;

        $this->enabled = $this->Config->init('header_proxy', 'enabled', $this->enabled, 'Включает обработку дополнительных заголовков');
        $this->header_ip = $this->Config->init('header_proxy', 'header_ip', $this->header_ip, 'ip-адрес');
        $this->header_http_version = $this->Config->init('header_proxy', 'header_http_version', $this->header_http_version, 'версия HTTP');
        $this->header_proto = $this->Config->init('header_proxy', 'header_protocol', $this->header_proto, 'http или https');

        // Список доверенных прокси. Пустая строка/Off — заголовки не доверяются даже при enabled=On.
        $trusted = $this->Config->init('header_proxy', 'trusted_proxies', '', 'Список IP/CIDR доверенных прокси через запятую. Пусто — никаким прокси не доверяем (поведение по умолчанию). Пример: 127.0.0.1,10.0.0.0/8');
        if (is_string($trusted) && $trusted !== '') {
            $this->trustedProxies = array_filter(array_map('trim', explode(',', $trusted)), function ($v) {
                return $v !== '';
            });
        } elseif (is_array($trusted)) {
            $this->trustedProxies = array_filter(array_map('trim', $trusted), function ($v) {
                return $v !== '';
            });
        }
    }

    /**
     * Возвращает true, если REMOTE_ADDR является доверенным прокси.
     */
    private function isTrustedProxy(): bool
    {
        if ($this->trustedProxies === null || empty($this->trustedProxies)) {
            return false;
        }
        $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '';
        if ($remoteAddr === '') {
            return false;
        }
        foreach ($this->trustedProxies as $entry) {
            if (\Utility\Network::isInRange($remoteAddr, $entry)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Возвращает IP адрес клиента с учетом прокси-серверов и балансировщиков.
     * Заголовок доверяется ТОЛЬКО если REMOTE_ADDR — доверенный прокси.
     */
    public function getIPAddr()
    {
        $result = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';

        if ($this->enabled && $this->isTrustedProxy()) {
            $header = $this->header_ip;

            if (!empty($_SERVER[$header])) {
                // Берём ПЕРВЫЙ (самый левый) IP — это исходный клиент в цепочке X-Forwarded-For: client, proxy1, proxy2
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);

                if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
                    throw new \RuntimeException('Value header "' . $header . '" is not a valid IP: ' . $ip);
                }
                return $ip;
            }
        }
        return $result;
    }

    /**
     * Получение протокола (http/https)
     */
    public function getProtocol()
    {
        $result = isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : '';
        if ($this->enabled && $this->isTrustedProxy()) {
            $header = $this->header_proto;
            if (!empty($_SERVER[$header])) {
                $proto = strtolower($_SERVER[$header]);
                if ($proto === 'https' || $proto === 'on') {
                    return 'https';
                }
                return 'http';
            }
        }
        return $result;
    }

    /**
     * Получает версию HTTP
     */
    public function getHttpVersion()
    {
        $result = isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : '';
        if ($this->enabled && $this->isTrustedProxy()) {
            $header = $this->header_http_version;
            if (!empty($_SERVER[$header])) {
                $result = $_SERVER[$header];
                if (preg_match('/(\d\.\d)/', $_SERVER[$header], $matches) === 1) {
                    $result = 'HTTP/' . $matches[1];
                }
                return $result;
            }
        }
        return $result;
    }

    /**
     * Определяет, использован ли HTTPS, с учётом прокси-заголовка.
     * Используется для флага Secure у cookie-маркера.
     */
    public function isHttps(): bool
    {
        if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        if (isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') {
            return true;
        }
        if ($this->enabled && $this->isTrustedProxy()) {
            $header = $this->header_proto;
            if (!empty($_SERVER[$header]) && strtolower($_SERVER[$header]) === 'https') {
                return true;
            }
        }
        return false;
    }
}
