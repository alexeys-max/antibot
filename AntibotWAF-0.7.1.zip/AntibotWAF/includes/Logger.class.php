<?php

namespace WAFSystem;

/**
 * Логирование посещений и системных событий.
 *
 * Три файла:
 * - antibot.log — запросы посетителей и решения WAF (через log()).
 * - debug.log   — системные события: кеш, драйверы, конфиг (через logDebug()).
 * - error.log   — ошибки и исключения (через logError()).
 *
 * БЕЗОПАСНОСТЬ:
 * - Пути к лог-файлам валидируются через Config::resolveSafePath().
 * - Все user-controlled поля очищаются от управляющих символов (\r, \n, \t).
 *
 * ПРОИЗВОДИТЕЛЬНОСТЬ:
 * - Записи буферизуются в памяти на протяжении запроса и сбрасываются
 *   одной операцией flock+fwrite в register_shutdown_function.
 * - Каждый файл имеет свой буфер и регистрирует shutdown-handler один раз.
 */
class Logger
{
    private $config;
    private $profile;

    private $logFile;          // antibot.log
    private $debugLogFile;     // debug.log
    private $errorLogFile;     // error.log
    private $debugEnabled;     // [main] debug — включает antibot.log
    private $debugLogEnabled;  // [logs] debug_log_enabled — включает debug.log
    private $apcuDebug;        // [logs] apcu_debug — детальное логирование APCu

    /** @var string[] Буфер antibot.log */
    private $buffer = [];
    /** @var string[] Буфер debug.log */
    private $debugBuffer = [];
    /** @var string[] Буфер error.log */
    private $errorBuffer = [];
    /** @var bool Флаг, что shutdown-handler уже зарегистрирован */
    private $shutdownRegistered = false;

    public function __construct(Config $config, Profile $profile)
    {
        $this->config = $config;
        $this->profile = $profile;

        $this->config->init('main', 'debug', true);
        $this->config->init('logs', 'log_file', 'logs/antibot.log');
        $this->config->init('logs', 'debug_log', 'logs/debug.log', 'файл системного debug-лога');
        $this->config->init('logs', 'error_log', 'logs/error.log', 'файл лога ошибок');
        $this->config->init('logs', 'debug_log_enabled', true, 'включить debug.log (системные события)');
        $this->config->init('logs', 'apcu_debug', false, 'детальное логирование APCu hit/miss в debug.log');
        $this->config->init('logs', 'max_size', 1, 'Максимальный размер, MB');
        $this->config->init('logs', 'rotate', 7, 'Количество файлов ротации');

        $this->debugEnabled = (bool)$this->config->get('main', 'debug', true);
        $this->debugLogEnabled = (bool)$this->config->get('logs', 'debug_log_enabled', true);
        $this->apcuDebug = (bool)$this->config->get('logs', 'apcu_debug', false);

        // БЕЗОПАСНОСТЬ: пути валидируются на path traversal.
        $logfile = $this->config->get('logs', 'log_file', 'logs/antibot.log');
        if (!is_string($logfile) || $logfile === '') {
            $logfile = 'logs/antibot.log';
            $this->config->set('logs', 'log_file', $logfile);
        }
        $this->logFile = $this->resolveLogPath($logfile);

        $debugLog = $this->config->get('logs', 'debug_log', 'logs/debug.log');
        if (!is_string($debugLog) || $debugLog === '') {
            $debugLog = 'logs/debug.log';
        }
        $this->debugLogFile = $this->resolveLogPath($debugLog);

        $errorLog = $this->config->get('logs', 'error_log', 'logs/error.log');
        if (!is_string($errorLog) || $errorLog === '') {
            $errorLog = 'logs/error.log';
        }
        $this->errorLogFile = $this->resolveLogPath($errorLog);

        $this->validateLogFile($this->logFile);
        if ($this->debugLogEnabled) {
            $this->validateLogFile($this->debugLogFile);
        }
        $this->validateLogFile($this->errorLogFile);
    }

    private function resolveLogPath(string $relativePath): string
    {
        try {
            return $this->config->resolveSafePath($relativePath);
        } catch (\RuntimeException $e) {
            return $this->config->BasePath . ltrim($relativePath, "/\\");
        }
    }

    /**
     * antibot.log — запросы и решения WAF.
     */
    public function logMessage($message)
    {
        if (!$this->debugEnabled) {
            return;
        }
        $message = $this->sanitizeForLog($message);
        $this->buffer[] = $this->formatLogEntry($message);
        $this->registerShutdown();
    }

    public function log($message, $context = [])
    {
        $fullMessage = $message;
        if (!empty($context)) {
            $cleanContext = array_map([$this, 'sanitizeForLog'], $context);
            $fullMessage .= " | " . json_encode($cleanContext, JSON_UNESCAPED_UNICODE);
        }
        $this->logMessage($fullMessage);
    }

    /**
     * debug.log — системные события (кеш, драйверы, конфиг, lists).
     * Пишет только если [logs] debug_log_enabled = On.
     */
    public function logDebug($message, $context = [])
    {
        if (!$this->debugLogEnabled) {
            return;
        }
        $fullMessage = $message;
        if (!empty($context)) {
            $cleanContext = array_map([$this, 'sanitizeForLog'], $context);
            $fullMessage .= " | " . json_encode($cleanContext, JSON_UNESCAPED_UNICODE);
        }
        $fullMessage = $this->sanitizeForLog($fullMessage);
        $this->debugBuffer[] = $this->formatLogEntry($fullMessage);
        $this->registerShutdown();
    }

    /**
     * error.log — ошибки и исключения.
     * Пишет всегда, независимо от debug.
     */
    public function logError($message, $context = [])
    {
        $fullMessage = $message;
        if (!empty($context)) {
            $cleanContext = array_map([$this, 'sanitizeForLog'], $context);
            $fullMessage .= " | " . json_encode($cleanContext, JSON_UNESCAPED_UNICODE);
        }
        $fullMessage = $this->sanitizeForLog($fullMessage);
        $this->errorBuffer[] = $this->formatLogEntry($fullMessage);
        $this->registerShutdown();
    }

    /**
     * APCu hit/miss в debug.log — только если [logs] apcu_debug = On.
     */
    public function logApcu(string $event, string $key = '')
    {
        if (!$this->apcuDebug || !$this->debugLogEnabled) {
            return;
        }
        $msg = "APCu {$event}";
        if ($key !== '') {
            $msg .= ": " . $key;
        }
        $this->logDebug($msg);
    }

    private function registerShutdown(): void
    {
        if (!$this->shutdownRegistered) {
            $this->shutdownRegistered = true;
            register_shutdown_function([$this, 'flush']);
        }
    }

    /**
     * Сбрасывает все буферы в соответствующие файлы.
     * Вызывается автоматически в register_shutdown_function.
     */
    public function flush(): void
    {
        if (!empty($this->buffer)) {
            $payload = implode('', $this->buffer);
            $this->buffer = [];
            $this->writeToFile($this->logFile, $payload);
        }
        if (!empty($this->debugBuffer) && $this->debugLogEnabled) {
            $payload = implode('', $this->debugBuffer);
            $this->debugBuffer = [];
            $this->writeToFile($this->debugLogFile, $payload);
        }
        if (!empty($this->errorBuffer)) {
            $payload = implode('', $this->errorBuffer);
            $this->errorBuffer = [];
            $this->writeToFile($this->errorLogFile, $payload);
        }
    }

    private function formatLogEntry($message)
    {
        $rayId = $this->sanitizeForLog($this->profile->RayID);
        $ip = $this->sanitizeForLog($this->profile->IP);
        return sprintf(
            "%s %s %s %s\n",
            date('Y-m-d H:i:s'),
            $rayId,
            $ip,
            $message
        );
    }

    private function writeToFile($filePath, $content)
    {
        $retry = 0;
        $maxRetries = 3;

        while ($retry < $maxRetries) {
            if ($handle = @fopen($filePath, 'a')) {
                if (flock($handle, LOCK_EX)) {
                    fwrite($handle, $content);
                    flock($handle, LOCK_UN);
                    fclose($handle);
                    return;
                }
                fclose($handle);
            }
            $retry++;
            usleep(100000);
        }

        // fallback в системный error_log, чтобы не терять сообщения.
        error_log("Antibot: failed to write log after {$maxRetries} attempts: " . $filePath);
    }

    private function sanitizeForLog($value)
    {
        if (!is_string($value)) {
            return $value;
        }
        return preg_replace('/[\x00-\x1F\x7F]/', ' ', $value);
    }

    private function validateLogFile($filePath)
    {
        if (file_exists($filePath) && !is_writable($filePath)) {
            throw new \RuntimeException("Log file is not writable: " . $filePath);
        }
        $logDir = dirname($filePath);
        if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
            throw new \RuntimeException("Failed to create log directory: " . $logDir);
        }
    }

    /**
     * Ротация логов — для всех трёх файлов.
     * Запускать из cron (cron/rotate_logs.php).
     */
    public function rotateIfNeeded()
    {
        $maxSizeMB = (int)$this->config->get('logs', 'max_size', 1);
        $rotateCount = (int)$this->config->get('logs', 'rotate', 7);

        $files = [$this->logFile];
        if ($this->debugLogEnabled) {
            $files[] = $this->debugLogFile;
        }
        $files[] = $this->errorLogFile;

        foreach ($files as $file) {
            if (is_file($file) && filesize($file) >= ($maxSizeMB * 1024 * 1024)) {
                $this->rotateSingleFile($file, $rotateCount);
            }
        }
    }

    private function rotateSingleFile($filePath, $rotateCount)
    {
        $tempFile = $filePath . '.temp_' . mt_rand();
        if (!rename($filePath, $tempFile)) {
            error_log("Failed to rename log file for rotation: " . $filePath);
            return;
        }

        touch($filePath);
        chmod($filePath, 0640);

        $this->processArchives($tempFile, $filePath, $rotateCount);
    }

    private function processArchives($sourceFile, $baseLogFile, $rotateCount)
    {
        $newArchive = $this->compressFile($sourceFile);
        if (!$newArchive) {
            unlink($sourceFile);
            return;
        }

        $oldestArchive = $baseLogFile . '.' . $rotateCount . '.gz';
        if (file_exists($oldestArchive)) {
            unlink($oldestArchive);
        }

        for ($i = $rotateCount - 1; $i >= 1; $i--) {
            $current = $baseLogFile . '.' . $i . '.gz';
            $new = $baseLogFile . '.' . ($i + 1) . '.gz';
            if (file_exists($current)) {
                rename($current, $new);
            }
        }

        rename($newArchive, $baseLogFile . '.1.gz');

        if (file_exists($sourceFile)) {
            unlink($sourceFile);
        }
    }

    private function compressFile($sourceFile)
    {
        if (!function_exists('gzopen')) {
            error_log("Zlib extension not available");
            return false;
        }

        $gzFile = $sourceFile . '.gz';
        $mode = 'wb9';

        $fp_out = gzopen($gzFile, $mode);
        if (!$fp_out) {
            error_log("Cannot create gzip file: " . $gzFile);
            return false;
        }

        $fp_in = fopen($sourceFile, 'rb');
        if (!$fp_in) {
            gzclose($fp_out);
            unlink($gzFile);
            error_log("Cannot read source file: " . $sourceFile);
            return false;
        }

        while (!feof($fp_in)) {
            gzwrite($fp_out, fread($fp_in, 4096));
        }

        fclose($fp_in);
        gzclose($fp_out);

        return $gzFile;
    }
}
