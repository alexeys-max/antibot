const head2 = document.getElementById("pSht7"),
    form = document.getElementById("uHkM6"),
    lspinner = document.getElementById("InsTY1"),
    blockSuccessful = document.getElementById("tWuBw3"),
    blockHTTPSecurity = document.getElementById("LfAMd3"),
    blockInput = document.getElementById("ihOWn1"),
    blockVerifying = document.getElementById("verifying"),
    blockFail = document.getElementById("fail"),
    checkboxLeft = document.getElementById("checkboxLeft"),
    checkboxRight = document.getElementById("checkboxRight"),
    verifyingText = document.getElementById("verifying-text"),
    failText = document.getElementById("fail-text"),
    expiredText = document.getElementById("expired-text"),
    timeoutText = document.getElementById("timeout-text"),
    expiredRefresh = document.getElementById("expired-refresh-link"),
    timeoutRefresh = document.getElementById("timeout-refresh-link"),
    // Новые элементы
    trapSpinner = document.getElementById("trapSpinner"),
    checkboxTrap = document.getElementById("checkboxTrap");

let CSRF = "",
    flagCloseWindow = !0,
    FINGERPRINT = '',
    FRAME_RATE = 0,
    IS_LOAD = {};

function refresh() {
    flagCloseWindow = !1;
    const e = new URL(window.location.href),
        t = document.referrer || "direct";
    SAVE_REFERER && localStorage.setItem("originalReferrer", t);
    UTM_REFERRER && "direct" != t && !e.searchParams.has("utm_referrer") && e.searchParams.set("utm_referrer", encodeURIComponent(t));
    window.location.href = e.toString();
}

function pageBlock() {
    flagCloseWindow = !1;
    const e = new URL(window.location.href);
    window.location.href = e.protocol + "//" + e.hostname + "/?awafblock";
}

function loadScript(e, t) {
    const n = t.name || "anonymous";
    IS_LOAD[n] = !1;
    var o = document.createElement("script");
    o.src = HTTP_ANTIBOT_PATH + e,
    o.async = !0,
    o.onload = t,
    o.onerror = function() {
        console.error("Error load: " + e);
    },
    document.head.appendChild(o);
}

function initFingerPrint() {
    typeof FingerprintJS != "undefined" ?
        FingerprintJS.load().then(e => e.get()).then(e => {
            FINGERPRINT = e.visitorId,
            IS_LOAD.initFingerPrint = !0;
        }) :
        console.error("initFingerPrint FingerprintJS no load");
}

function callbackFrameRate() {
    typeof FrameRateJS != "undefined" ?
        FrameRateJS.load().then(e => {
            FRAME_RATE = e,
            IS_LOAD.callbackFrameRate = !0;
        }) :
        console.error("callbackFrameRate FrameRateJS no load");
}

function getObjectBrowser(e, t = { includeNull: !1, includeEmpty: !1 }) {
    if (e instanceof HTMLAllCollection) return;
    const n = ["[object HTMLAllCollection]", "[object HTMLCollection]", "[object NodeList]"];
    if (n.includes(Object.prototype.toString.call(e))) return;
    if (null === e) return t.includeNull ? null : void 0;
    if ("object" != typeof e) return e;
    if (e instanceof Date) return e.toISOString();
    if (e instanceof RegExp) return e.toString();
    if (e instanceof HTMLElement || e instanceof Function) return;
    const o = {};
    let r = !1,
        s = [];
    for (const n in e) s.push(n);
    const c = Object.getOwnPropertySymbols(e);
    for (const t of c) s.push(t);
    for (const n of s) {
        try {
            if ("__proto__" === n || "constructor" === n) continue;
            const s = "symbol" == typeof n ? e[n] : e[n];
            if ("function" == typeof s || s instanceof HTMLElement) continue;
            if (null !== s && "object" == typeof s) continue;
            if (void 0 !== s && (t.includeNull || null !== s)) {
                const e = "symbol" == typeof n ? `Symbol(${n.description || ""})` : n;
                o[e] = s, r = !0;
            }
        } catch (e) {
            continue;
        }
    }
    return r ? o : t.includeEmpty ? {} : void 0;
}

function checkBot(e) {
    var t = new XMLHttpRequest,
        n = new Date;
    let o = {
        func: void 0 === e ? "csrf_token" : e,
        csrf_token: CSRF,
        mainFrame: window.top === window.self
    };
    if (void 0 !== e) {
        const r = {
            datetime: {
                now: n.toISOString(),
                timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown",
                offsetHours: -(n.getTimezoneOffset() / 60)
            },
            clientWidth: document.documentElement.clientWidth,
            clientHeight: document.documentElement.clientHeight,
            screenWidth: window.screen.width,
            screenHeight: window.screen.height,
            pixelRatio: window.devicePixelRatio || 1,
            colorDepth: window.screen.colorDepth,
            pixelDepth: window.screen.pixelDepth,
            java: window.java ? 1 : 0,
            referer: document.referrer,
            document: getObjectBrowser(document),
            window: getObjectBrowser(window),
            navigator: getObjectBrowser(navigator),
            screen: getObjectBrowser(window.screen),
            location: getObjectBrowser(window.location),
            fingerPrint: FINGERPRINT,
            isBas: isBas(),
            frameRate: FRAME_RATE
        };
        Object.assign(o, r);
    }
    let r = null;
    try {
        r = JSON.stringify(o);
    } catch (e) {
        console.error("Failed to stringify data:", e);
    }
    t.open("POST", HTTP_ANTIBOT_PATH + "xhr.php", !0),
    t.setRequestHeader("Content-Type", "application/json"),
    t.onload = function() {
        if (t.status >= 200 && t.status < 300) {
            var e = JSON.parse(t.responseText);
            CSRF = e.csrf_token;
            if (void 0 === CSRF || "" == CSRF) console.log("Error getting csrf_token");
            else if ("csrf_token" === e.func) {
                loadScript("js/frame_rate.js", callbackFrameRate);
                loadScript("js/fp.min.js", initFingerPrint);
            } else if ("captcha" === e.status) {
                lspinner.style.display = "none";
                form.style.display = "grid";
                blockInput.style.display = "";
                displayCaptcha();
            } else if ("allow" === e.status) {
                form.style.display = "none";
                lspinner.style.display = "none";
                blockHTTPSecurity.style.display = "none";
                blockSuccessful.style.display = "block";
                setTimeout(refresh, 1e3);
            } else if ("block" === e.status) {
                setTimeout(pageBlock, 1e3);
            } else if ("fail" === e.status) {
                form.style.display = "grid";
                lspinner.style.display = "none";
                blockHTTPSecurity.style.display = "none";
                blockFail.style.display = "grid";
                blockInput.style.display = "none";
            } else if ("refresh" === e.status) {
                setTimeout(refresh, 1e3);
            } else console.log(e);
        }
    },
    t.onerror = function() {
        console.error("Network error occurred");
    },
    t.send(r);
}

// Новая функция для отображения спиннера-ловушки на 20 секунд
function showTrapSpinner() {
    flagCloseWindow = false; // предотвращаем срабатывание onbeforeunload

    // Скрываем все возможные блоки
    lspinner.style.display = 'none';
    blockHTTPSecurity.style.display = 'none';
    blockInput.style.display = 'none';
    blockVerifying.style.display = 'none';
    blockFail.style.display = 'none';
    blockSuccessful.style.display = 'none';

    // Скрываем также expired и timeout, если они есть
    const expired = document.getElementById('expired');
    const timeout = document.getElementById('timeout');
    if (expired) expired.style.display = 'none';
    if (timeout) timeout.style.display = 'none';

    // Показываем спиннер-ловушку
    trapSpinner.style.display = 'grid';

    // Через 20 секунд очищаем страницу
    setTimeout(function() {
        document.body.innerHTML = '';
    }, 20000);
}

function displayCaptcha() {
    const e = 0 === REAL_CHECKBOX_SIDE ? checkboxLeft : checkboxRight; // правильный
    const t = 0 === REAL_CHECKBOX_SIDE ? checkboxRight : checkboxLeft; // неправильный

    head2.textContent = LANG_DATA.instruction;
    verifyingText.textContent = LANG_DATA.verifying;
    failText.textContent = LANG_DATA.failure;
    expiredText.textContent = LANG_DATA.session_expired + " .";
    timeoutText.textContent = LANG_DATA.time_expired + " .";
    expiredRefresh.textContent = LANG_DATA.refresh;
    timeoutRefresh.textContent = LANG_DATA.refresh;

    // Обработчик для правильного чекбокса (без изменений)
    e.addEventListener("click", function(o) {
        if (this.checked) {
            METRIKA_ID != "" && (function() {
                try {
                    ym(METRIKA_ID, "reachGoal", "onclickcapcha");
                } catch (e) {}
            })();
            blockInput.style.display = "none";
            blockVerifying.style.display = "";
            checkBot("set-marker");
        }
    });

    // ЗАМЕНА: обработчик для неправильного чекбокса – теперь запускает ловушку
    t.addEventListener("click", function(e) {
        if (this.checked) {
            showTrapSpinner();
        }
    });

    // НОВЫЙ обработчик для чекбокса-ловушки
    if (checkboxTrap) {
        checkboxTrap.addEventListener("click", function(e) {
            if (this.checked) {
                showTrapSpinner();
            }
        });
    }

    window.onbeforeunload = function(e) {
        flagCloseWindow && checkBot("win-close");
    };

    displayNone();
    form.style.display = "grid";
    blockInput.style.display = "";
}

function displayNone() {
    lspinner.style.display = "none";
    blockHTTPSecurity.style.display = "none";
    blockInput.style.display = "none";
    blockVerifying.style.display = "none";
    // trapSpinner не скрываем здесь – он управляется отдельно
}

function ymc(e, t) {
    if (typeof ym != "function")
        try {
            !function(e, t, n, o, r, s, c) {
                e[r] = e[r] || function() {
                    (e[r].a = e[r].a || []).push(arguments);
                }, e[r].l = 1 * new Date;
                for (var i = 0; i < document.scripts.length; i++)
                    if (document.scripts[i].src === o) return;
                c = t.createElement(n), s = t.getElementsByTagName(n)[0], c.async = 1, c.src = o, s.parentNode.insertBefore(c, s);
            }(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym"),
            ym(e, "init", {
                clickmap: !0,
                trackLinks: !0,
                accurateTrackBounce: !0,
                webvisor: !0,
                params: {
                    ip: t
                }
            });
        } catch (e) {}
}

function сheckCookie() {
    return document.cookie = "testcookie=1; SameSite=Lax; path=/",
        document.cookie.includes("testcookie=") ? (document.cookie = "testcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/", !0) : (document.cookie = "testcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/", !1);
}

function isBas() {
    return Object.create(location.reload),
        Reflect.ownKeys(location.reload).length === 3;
}

METRIKA_ID != "" && ymc(METRIKA_ID, REMOTE_ADDR);

if (!сheckCookie()) {
    displayNone();
    const e = document.querySelectorAll("noscript"),
        t = document.createElement("div");
    t.innerHTML = e[0].innerHTML,
    e[0].replaceWith(t);
} else {
    const e = setInterval(() => {
        try {
            if (Object.keys(IS_LOAD).length > 0) {
                let t = !0;
                for (const e of Object.values(IS_LOAD))
                    if (!e) {
                        t = !1;
                        break;
                    }
                t && (checkBot("checks"), clearInterval(e));
            }
        } catch (e) {
            console.error("Ошибка:", e);
        }
    }, 500);
    checkBot();
}